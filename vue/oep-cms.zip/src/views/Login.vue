<template>
	<div class="login_container">
		<div class="login_box">
			<div class="title">
				<img src="../assets/img/logo.png" alt="" height="60">
			</div>
			<!--登录表单-->
			<el-form ref="loginFormRef" :model="loginForm" :rules="loginFormRules" class="login_form">
				<el-form-item prop="username">
					<el-input v-model="loginForm.username" prefix-icon="el-icon-user-solid"></el-input>
				</el-form-item>
				<el-form-item prop="password">
					<el-input v-model="loginForm.password" prefix-icon="el-icon-lock" show-password></el-input>
				</el-form-item>
				<el-form-item class="btns">
					<el-button type="primary" @click="login">登录</el-button>
					<el-button type="info" @click="resetLoginForm">重置</el-button>
				</el-form-item>
			</el-form>
		</div>
	</div>
</template>

<script>
import Ribbon from '@/assets/js/ribbon'
import Index from '@/api/admin/index'

export default {
  name: 'Login',
	components: {
		Ribbon
	},
  data() {
    return {
      loginForm: {
        username: '',
        password: ''
      },
      loginFormRules: {
				username: [
					{required: true, message: '请输入用户名', trigger: 'blur'},
				],
				password: [
					{required: true, message: '请输入密码', trigger: 'blur'},
				]
			}
    }
  },
  methods: {
	  login() {
	  	this.$refs.loginFormRef.validate(valid => {
	  		if (valid) {
	  			Index.login(this.loginForm)
					.then(res => {
					if (res.code === 20000) {
						const token = res.data.tokenHead+' '+res.data.token
						window.sessionStorage.setItem('token',token)
						this.$router.replace('/dashboard')
					}
					})
	  		}
	  	})
	  },
    resetLoginForm() {
	  	this.$refs.loginFormRef.resetFields();
	  },
  }
}
</script>

<style scoped>
.login_container {
		height: 100%;
	}

	.login_box {
		width: 450px;
		height: 300px;
		background-color: rgb(255, 255, 255);
		border-radius: 3px;
		position: absolute;
		left: 50%;
		top: 50%;
		transform: translate(-50%, -50%);
	}

	.login_box .title {
		position: absolute;
		left: 50%;
		transform: translate(-50%, -50%);
		top: 60px;
	}


	.login_form {
		position: absolute;
		bottom: 0;
		width: 100%;
		padding: 0 20px;
		box-sizing: border-box;
	}

	.btns {
		display: flex;
		justify-content: flex-end;
	}
</style>