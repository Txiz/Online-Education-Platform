<template>
  <div>
    <!-- 面包屑导航 -->
    <Breadcrumb parentTitle="评论管理" />
    <el-card>
      <!-- 评论列表 -->
      <el-table
        v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.8)"
        :data="comments"
        row-key="commentId"
        default-expand-all
        :tree-props="{ children: 'children', hasChildren: true }"
      >
        <el-table-column
          label="评论内容"
          prop="commentContent"
          min-width="150"
        ></el-table-column>
        <el-table-column
          label="用户昵称"
          prop="peopleNickName"
        ></el-table-column>
        <el-table-column label="课程名称" prop="courseName" min-width="100"></el-table-column>
        <el-table-column label="是否启用">
          <template v-slot="scope">
            <el-switch
              v-model="scope.row.isEnable"
              @change="updateIsEnable(scope.row)"
            ></el-switch>
          </template>
        </el-table-column>
        <el-table-column label="创建时间" min-width="100">
          <template v-slot="scope">{{
            scope.row.createTime | dateFormat
          }}</template>
        </el-table-column>
        <el-table-column label="更新时间" min-width="100">
          <template v-slot="scope">{{
            scope.row.updateTime | dateFormat
          }}</template>
        </el-table-column>
        <el-table-column label="操作" fixed="right">
          <template v-slot="scope">
            <el-button
              class="table_button"
              type="danger"
              icon="el-icon-delete"
              circle
              @click="deleteCommentById(scope.row.commentId)"
            ></el-button>
          </template>
        </el-table-column>
      </el-table>
      <!--分页插件-->
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="page"
        :page-sizes="[20, 50, 100]"
        :page-size="size"
        :total="total"
        layout="total, sizes, prev, pager, next, jumper"
        background
      >
      </el-pagination>
    </el-card>
  </div>
</template>

<script>
import Breadcrumb from "@/components/Breadcrumb";
import Comment from "@/api/education/comment";

export default {
  name: "Comment",
  components: {
    Breadcrumb,
  },
  data() {
    return {
      comments: [],
      total: 0,
      page: 1,
      size: 20,
      loading: true
    };
  },
  created() {
    this.loading = true
    this.pageComment();
    this.loading = false
  },
  methods: {
    pageComment(page = 1) {
      this.page = page;
      Comment.pageComment(this.page, this.size).then((res) => {
        if (res.code === 20000) {
          this.msgSuccess(res.message);
          this.comments = res.data.commentList;
          this.total = res.data.total;
        }
      });
    },
    updateIsEnable(row) {
      Comment.saveOrUpdateComment(row).then((res) => {
        if (res.code === 20000) {
          this.msgSuccess(res.message);
          this.pageComment();
        }
      });
    },
    deleteCommentById(commentId) {
      this.$confirm("此操作将删除该标签，是否删除?", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(() => {
        Comment.deleteCommentById(commentId).then((res) => {
          if (res.code === 20000) {
            this.msgSuccess(res.message);
            this.pageComment();
          }
        });
      });
    },
    // 分页插件，监听size改变事件
    handleSizeChange(newSize) {
      this.size = newSize;
      this.pageComment();
    },
    // 分页插件，监听page改变的事件
    handleCurrentChange(newPage) {
      this.page = newPage;
      this.pageComment(this.page);
    },
  },
};
</script>

<style scoped>
.table_button {
  margin-left: 10px;
}
</style>
