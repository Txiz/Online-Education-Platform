<template>
  <div>
    <!-- 面包屑导航 -->
    <Breadcrumb parentTitle="账号管理" />
    <el-card class="box-card">
      <!--模糊搜索-->
      <el-form :inline="true" class="demo-form-inline">
        <el-form-item>
          <el-date-picker
            v-model="peopleSearchVo.beginTime"
            type="datetime"
            placeholder="选择开始时间"
            value-format="yyyy-MM-dd HH:mm:ss"
            default-time="00:00:00"
          />
        </el-form-item>
        <el-form-item>
          <el-date-picker
            v-model="peopleSearchVo.endTime"
            type="datetime"
            placeholder="选择截止时间"
            value-format="yyyy-MM-dd HH:mm:ss"
            default-time="00:00:00"
          />
        </el-form-item>
        <el-form-item>
          <el-input
            v-model="peopleSearchVo.peopleName"
            placeholder="账号名称"
          />
        </el-form-item>
        <el-form-item>
          <el-input
            v-model="peopleSearchVo.nickName"
            placeholder="账号持有人"
          />
        </el-form-item>
        <el-form-item>
          <el-switch
            v-model="peopleSearchVo.isWho"
            active-text="账号身份"
          ></el-switch>
        </el-form-item>
      </el-form>
      <!-- 添加用户-->
      <el-button
        type="primary"
        icon="el-icon-plus"
        @click="saveDialogVisible = true"
        >添加</el-button
      >
      <el-button type="success" icon="el-icon-search" @click="searchPeople()"
        >查询</el-button
      >
      <el-button type="default" icon="el-icon-refresh" @click="reset()"
        >重置</el-button
      >
      <el-upload
        class="upload-demo"
        action="#"
        :http-request="savePeopleByUseExcel"
        style="float: right"
      >
        <el-button type="warning" icon="el-icon-upload">批量导入</el-button>
      </el-upload>
      <!-- 用户列表 -->
      <el-table
        v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.8)"
        :data="peoples"
      >
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="账号头像" width="80">
          <template v-slot="scope">
            <el-image :src="scope.row.avatar" fit="cover"> </el-image>
          </template>
        </el-table-column>
        <el-table-column label="账号名称" prop="peopleName" min-width="100"></el-table-column>
        <el-table-column label="账号持有人" prop="nickName"></el-table-column>
        <el-table-column label="账号身份">
          <template v-slot="scope">{{
            scope.row.isWho ? "教师" : "学生"
          }}</template>
        </el-table-column>
        <el-table-column label="创建时间" min-width="100">
          <template v-slot="scope">{{
            scope.row.createTime | dateFormat
          }}</template>
        </el-table-column>
        <el-table-column label="更新时间" min-width="100">
          <template v-slot="scope">{{
            scope.row.updateTime | dateFormat
          }}</template>
        </el-table-column>
        <el-table-column label="操作" fixed="right" min-width="120">
          <template v-slot="scope">
            <el-button
              class="table_button"
              type="primary"
              icon="el-icon-edit"
              circle
              @click="show(scope.row)"
            ></el-button>
            <el-button
              class="table_button"
              type="danger"
              icon="el-icon-delete"
              circle
              @click="deletePeopleById(scope.row.peopleId)"
            ></el-button>
          </template>
        </el-table-column>
      </el-table>
      <!--分页插件-->
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="page"
        :page-sizes="[20, 50, 100]"
        :page-size="size"
        :total="total"
        layout="total, sizes, prev, pager, next, jumper"
        background
      >
      </el-pagination>
    </el-card>
    <!--添加用户对话框-->
    <el-dialog
      v-if="saveDialogVisible"
      title="添加用户"
      width="50%"
      :visible.sync="saveDialogVisible"
      :close-on-click-modal="false"
      @close="saveDialogClosed"
    >
      <el-form
        :model="saveForm"
        ref="saveFormRef"
        label-width="80px"
        :rules="saveFormRules"
      >
        <el-form-item label="用户名" prop="peopleName">
          <el-input v-model="saveForm.peopleName"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="saveForm.password" show-password></el-input>
        </el-form-item>
        <el-form-item label="姓名" prop="nickName">
          <el-input v-model="saveForm.nickName"></el-input>
        </el-form-item>
        <el-form-item label="账号头像">
          <el-upload
            width="80"
            class="avatar-uploader"
            action="#"
            :http-request="saveAvatar"
          >
            <i class="el-icon-plus" v-if="!saveForm.avatar" />
            <el-image v-if="saveForm.avatar" :src="saveForm.avatar"></el-image>
          </el-upload>
        </el-form-item>
        <el-form-item label="教师/学生">
          <el-select v-model="saveForm.isWho">
            <el-option value="true" label="教师"> 教师 </el-option>
            <el-option value="false" label="学生"> 学生 </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="saveDialogClosed">取 消</el-button>
        <el-button type="primary" @click="savePeople">确 定</el-button>
      </span>
    </el-dialog>
    <!--更新用户对话框-->
    <el-dialog
      v-if="updateDialogVisible"
      title="编辑用户"
      width="50%"
      :visible.sync="updateDialogVisible"
      :close-on-click-modal="false"
      @close="updateDialogClosed"
    >
      <!--内容主体-->
      <el-form
        :model="updateForm"
        ref="updateFormRef"
        label-width="80px"
        :rules="updateFormRules"
      >
        <el-form-item label="用户名" prop="peopleName">
          <el-input v-model="updateForm.peopleName"></el-input>
        </el-form-item>
        <el-form-item label="姓名" prop="nickName">
          <el-input v-model="updateForm.nickName"></el-input>
        </el-form-item>
        <el-form-item label="账号头像">
          <el-upload
            width="80"
            class="avatar-uploader"
            action="#"
            :http-request="updateAvatar"
          >
            <i class="el-icon-plus" v-if="!updateForm.avatar" />
            <el-image
              v-if="updateForm.avatar"
              :src="updateForm.avatar"
            ></el-image>
          </el-upload>
        </el-form-item>
        <el-form-item label="教师/学生">
          <el-select v-model="updateForm.isWho">
            <el-option value="1" label="true">教师</el-option>
            <el-option value="0" label="false">学生</el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <!--底部-->
      <span slot="footer">
        <el-button @click="updateDialogClosed">取 消</el-button>
        <el-button type="primary" @click="updatePeople">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import Breadcrumb from "@/components/Breadcrumb";
import People from "@/api/education/people";
import Oss from "@/api/oss/oss";
export default {
  name: "People",
  components: {
    Breadcrumb,
  },
  data() {
    return {
      peoples: [],
      peopleSearchVo: {},
      total: 0,
      page: 1,
      size: 20,
      saveDialogVisible: false,
      updateDialogVisible: false,
      saveForm: {},
      updateForm: {},
      options: {
        FontAwesome: false,
        ElementUI: true,
      },
      saveFormRules: {
        peopleName: [
          { required: true, message: "请输入用户名", trigger: "blur" },
        ],
        password: [{ required: true, message: "请输入密码", trigger: "blur" }],
        nickName: [{ required: true, message: "请输入姓名", trigger: "blur" }],
      },
      updateFormRules: {
        peopleName: [
          { required: true, message: "请输入用户名", trigger: "blur" },
        ],
        nickName: [{ required: true, message: "请输入姓名", trigger: "blur" }],
      },
      loading: true,
    };
  },
  created() {
    this.loading = true;
    this.pagePeople();
    this.loading = false;
  },
  methods: {
    pagePeople(page = 1) {
      this.page = page;
      People.pagePeople(this.page, this.size).then((res) => {
        if (res.code === 20000) {
          this.msgSuccess(res.message);
          this.peoples = res.data.peopleList;
          this.total = res.data.total;
        }
      });
    },
    savePeople() {
      this.$refs.saveFormRef.validate((valid) => {
        if (valid) {
          People.saveOrUpdatePeople(this.saveForm).then((res) => {
            if (res.code === 20000) {
              this.msgSuccess(res.message);
              this.saveDialogClosed();
              this.pagePeople();
            }
          });
        }
      });
    },
    updatePeople() {
      this.$refs.updateFormRef.validate((valid) => {
        if (valid) {
          People.saveOrUpdatePeople(this.updateForm).then((res) => {
            if (res.code === 20000) {
              this.msgSuccess(res.message);
              this.updateDialogVisible = false;
              this.pagePeople();
            }
          });
        }
      });
    },
    deletePeopleById(peopleId) {
      this.$confirm("此操作将删除该标签，是否删除?", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(() => {
        People.deletePeopleById(peopleId).then((res) => {
          if (res.code === 20000) {
            this.msgSuccess(res.message);
            this.pagePeople();
          }
        });
      });
    },
    show(row) {
      //row中没有对象(blogList是表单不需要的属性)
      //直接拓展运算符深拷贝一份(拓展运算符不能深拷贝对象，只能拷贝引用)
      //如果直接赋值，则为引用，表格上的数据也会随对话框中数据的修改而实时改变
      this.updateForm = { ...row };
      this.updateDialogVisible = true;
    },
    // 分页插件，监听size改变事件
    handleSizeChange(newSize) {
      this.size = newSize;
      this.pagePeople();
    },
    // 分页插件，监听page改变的事件
    handleCurrentChange(newPage) {
      this.page = newPage;
      this.pagePeople(this.page);
    },
    // 关闭添加用户对话框
    saveDialogClosed() {
      this.saveForm = {};
      this.$refs.saveFormRef.resetFields();
      this.saveDialogVisible = false;
    },
    // 关闭编辑菜单对话框
    updateDialogClosed() {
      this.$refs.updateFormRef.resetFields();
      this.updateDialogVisible = false;
    },
    searchPeople(page = 1) {
      console.log(this.peopleSearchVo);
      this.page = page;
      People.searchPeople(this.page, this.size, this.peopleSearchVo).then(
        (res) => {
          if (res.code === 20000) {
            this.msgSuccess(res.message);
            this.peoples = res.data.peopleList;
            this.total = res.data.total;
          }
        }
      );
    },
    resetData() {
      //清空的方法
      //表单输入项数据清空
      this.peopleSearchVo = {};
      this.pagePeople();
    },
    saveAvatar(param) {
      let fd = new FormData();
      fd.append("file", param.file);
      Oss.uploadFile(fd).then((res) => {
        if (res.code === 20000) {
          this.saveForm.avatar = res.data.url;
        }
      });
    },
    updateAvatar(param) {
      let fd = new FormData();
      fd.append("file", param.file);
      Oss.uploadFile(fd).then((res) => {
        if (res.code === 20000) {
          this.updateForm.avatar = res.data.url;
        }
      });
    },
    savePeopleByUseExcel(param) {
      let fd = new FormData();
      fd.append("file", param.file);
      People.savePeopleByUseExcel(fd).then((res) => {
        if (res.code === 20000) {
          this.msgSuccess(res.message);
          this.pagePeople();
        }
      });
    },
  },
};
</script>

<style scoped>
  .table_button {
    margin-left: 10px;
  }
  .el-image {
    max-width: 100px;
  }
</style>