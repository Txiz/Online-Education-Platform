<template>
  <div>
    <!-- 面包屑导航 -->
    <Breadcrumb parentTitle="角色管理" />
    <el-card class="box-card">
      <!--模糊搜索-->
      <el-form :inline="true">
        <el-form-item>
          <el-date-picker
            v-model="roleSearchVo.beginTime"
            type="datetime"
            placeholder="选择开始时间"
            value-format="yyyy-MM-dd HH:mm:ss"
            default-time="00:00:00"
          />
        </el-form-item>
        <el-form-item>
          <el-date-picker
            v-model="roleSearchVo.endTime"
            type="datetime"
            placeholder="选择截止时间"
            value-format="yyyy-MM-dd HH:mm:ss"
            default-time="00:00:00"
          />
        </el-form-item>
        <el-form-item>
          <el-input v-model="roleSearchVo.roleName" placeholder="角色名称" />
        </el-form-item>
        <el-form-item>
          <el-input v-model="roleSearchVo.nickName" placeholder="角色昵称" />
        </el-form-item>
      </el-form>
      <!-- 功能按钮 -->
      <el-button
        type="primary"
        icon="el-icon-plus"
        @click="saveDialogVisible = true"
        >添加</el-button
      >
      <el-button type="success" icon="el-icon-search" @click="searchRole()"
        >查询</el-button
      >
      <el-button type="default" icon="el-icon-refresh" @click="reset()"
        >重置</el-button
      >
      <!-- 角色列表 -->
      <el-table
        v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.8)"
        :data="roleList"
      >
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column label="角色名称" prop="roleName" min-width="90"></el-table-column>
        <el-table-column label="角色昵称" prop="nickName" min-width="90"></el-table-column>
        <el-table-column label="创建时间" min-width="100">
          <template v-slot="scope">{{
            scope.row.createTime | dateFormat
          }}</template>
        </el-table-column>
        <el-table-column label="更新时间" min-width="100">
          <template v-slot="scope">{{
            scope.row.updateTime | dateFormat
          }}</template>
        </el-table-column>
        <el-table-column label="操作" fixed="right" min-width="120">
          <template v-slot="scope">
            <el-button
              class="table_button"
              type="primary"
              icon="el-icon-edit"
              circle
              @click="show(scope.row)"
            ></el-button>
            <el-button
              class="table_button"
              type="danger"
              icon="el-icon-delete"
              circle
              @click="deleteRoleById(scope.row.roleId)"
            ></el-button>
          </template>
        </el-table-column>
      </el-table>
      <!--分页插件-->
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="page"
        :page-sizes="[5, 10, 20, 50]"
        :page-size="size"
        :total="total"
        layout="total, sizes, prev, pager, next, jumper"
        background
      >
      </el-pagination>
    </el-card>
    <!--添加角色对话框-->
    <el-dialog
      v-if="saveDialogVisible"
      title="添加角色"
      width="50%"
      :visible.sync="saveDialogVisible"
      :close-on-click-modal="false"
      @close="saveDialogClosed"
    >
      <el-form
        :model="saveForm"
        ref="saveFormRef"
        label-width="80px"
        :rules="saveFormRules"
      >
        <el-form-item label="角色名称" prop="roleName">
          <el-input v-model="saveForm.roleName"></el-input>
        </el-form-item>
        <el-form-item label="角色昵称" prop="nickName">
          <el-input v-model="saveForm.nickName"></el-input>
        </el-form-item>
        <el-form-item label="接口权限">
          <el-checkbox-group v-model="saveForm.apiIds">
            <el-checkbox
              v-for="item in apiAuthList"
              :key="item.apiId"
              :label="item.apiId"
              :value="item.apiId"
            >
              {{ item.apiName }}
            </el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="菜单列表">
          <el-tree
            v-model="saveForm.menuIds"
            :data="menuTree"
            :props="defaultProps"
            :default-checked-keys="saveForm.menuIds"
            node-key="menuId"
            ref="saveMenuTreeRef"
            show-checkbox
            :check-strictly="true"
            default-expand-all
          >
          </el-tree>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="saveDialogClosed">取 消</el-button>
        <el-button type="primary" @click="saveRole">确 定</el-button>
      </span>
    </el-dialog>
    <!--更新角色对话框-->
    <el-dialog
      v-if="updateDialogVisible"
      title="编辑角色"
      width="50%"
      :visible.sync="updateDialogVisible"
      :close-on-click-modal="false"
      @close="updateDialogClosed"
    >
      <!--内容主体-->
      <el-form
        :model="updateForm"
        ref="updateFormRef"
        label-width="80px"
        :rules="updateFormRules"
      >
        <el-form-item label="角色名称" prop="roleName">
          <el-input v-model="updateForm.roleName"></el-input>
        </el-form-item>
        <el-form-item label="角色昵称" prop="nickName">
          <el-input v-model="updateForm.nickName"></el-input>
        </el-form-item>
        <el-form-item label="接口权限">
          <el-checkbox-group v-model="updateForm.apiIds">
            <el-checkbox
              v-for="item in apiAuthList"
              :key="item.apiId"
              :label="item.apiId"
              :value="item.apiId"
            >
              {{ item.apiName }}
            </el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="菜单列表">
          <el-tree
            v-model="updateForm.menuIds"
            :data="menuTree"
            :props="defaultProps"
            :default-checked-keys="updateForm.menuIds"
            node-key="menuId"
            ref="updateMenuTreeRef"
            show-checkbox
            :check-strictly="true"
            default-expand-all
          >
          </el-tree>
        </el-form-item>
      </el-form>
      <!--底部-->
      <span slot="footer">
        <el-button @click="updateDialogClosed">取 消</el-button>
        <el-button type="primary" @click="updateRole">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import Breadcrumb from "@/components/Breadcrumb";
import Role from "@/api/admin/role";
import Api from "@/api/admin/api";
import Menu from "@/api/admin/menu";

export default {
  name: "Role",
  components: {
    Breadcrumb,
  },
  data() {
    return {
      roleList: [],
      apiAuthList: [],
      menuTree: [],
      total: 0,
      page: 1,
      size: 5,
      saveDialogVisible: false,
      updateDialogVisible: false,
      saveForm: {
        apiIds: [],
        menuIds: [],
      },
      updateForm: {},
      defaultProps: {
        children: "children",
        label: "menuName",
      },
      roleSearchVo: {},
      saveFormRules: {
        roleName: [
          { required: true, message: "请输入角色名称", trigger: "blur" },
        ],
      },
      updateFormRules: {
        roleName: [
          { required: true, message: "请输入角色名称", trigger: "blur" },
        ],
      },
      loading: true,
    };
  },
  created() {
    this.loading = true;
    this.init();
    this.pageRole();
    this.loading = false;
  },
  methods: {
    init() {
      Api.listAuthApi().then((res) => {
        if (res.code === 20000) {
          this.apiAuthList = res.data.apiAuthList;
        }
      });
      Menu.listMenuTree().then((res) => {
        if (res.code === 20000) {
          this.menuTree = res.data.menuTree;
        }
      });
    },
    pageRole(page = 1) {
      this.page = page;
      Role.pageRole(this.page, this.size).then((res) => {
        if (res.code === 20000) {
          this.msgSuccess(res.message);
          this.roleList = res.data.roleList;
          this.total = res.data.total;
        }
      });
    },
    show(row) {
      //row中没有对象(blogList是表单不需要的属性)
      //直接拓展运算符深拷贝一份(拓展运算符不能深拷贝对象，只能拷贝引用)
      //如果直接赋值，则为引用，表格上的数据也会随对话框中数据的修改而实时改变
      this.updateForm = { ...row };
      this.updateDialogVisible = true;
    },
    saveRole() {
      this.$refs.saveFormRef.validate((valid) => {
        if (valid) {
          this.saveForm.menuIds = this.$refs.saveMenuTreeRef.getCheckedKeys();
          Role.saveOrUpdateRole(this.saveForm).then((res) => {
            if (res.code === 20000) {
              this.msgSuccess(res.message);
              this.saveDialogClosed();
              this.pageRole();
            }
          });
        }
      });
    },
    updateRole() {
      this.$refs.updateFormRef.validate((valid) => {
        if (valid) {
          this.updateForm.menuIds = this.$refs.updateMenuTreeRef.getCheckedKeys();
          Role.saveOrUpdateRole(this.updateForm).then((res) => {
            if (res.code === 20000) {
              this.msgSuccess(res.message);
              this.updateDialogVisible = false;
              this.pageRole();
            }
          });
        }
      });
    },
    deleteRoleById(roleId) {
      this.$confirm("此操作将删除该标签，是否删除?", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(() => {
        Role.deleteRoleById(roleId).then((res) => {
          if (res.code === 20000) {
            this.msgSuccess(res.message);
            this.pageRole();
          }
        });
      });
    },
    // 分页插件，监听size改变事件
    handleSizeChange(newSize) {
      this.size = newSize;
      this.pageRole();
    },
    // 分页插件，监听page改变的事件
    handleCurrentChange(newPage) {
      this.page = newPage;
      this.pageRole(this.page);
    },
    // 关闭添加分类对话框
    saveDialogClosed() {
      this.saveForm = {};
      this.$refs.saveMenuTreeRef.setCheckedKeys([]);
      this.$refs.saveFormRef.resetFields();
      this.saveDialogVisible = false;
    },
    // 关闭编辑分类对话框
    updateDialogClosed() {
      this.$refs.updateMenuTreeRef.setCheckedKeys([]);
      this.$refs.updateFormRef.resetFields();
      this.updateDialogVisible = false;
    },
    searchRole(page = 1) {
      this.page = page;
      Role.searchRole(this.page, this.size, this.roleSearchVo).then((res) => {
        if (res.code === 20000) {
          this.msgSuccess(res.message);
          this.roleList = res.data.roleList;
          this.total = res.data.total;
        }
      });
    },
    reset() {
      //清空的方法
      //表单输入项数据清空
      this.roleSearchVo = {};
      this.pageRole();
    },
  },
};
</script>

<style scoped>
.table_button {
  margin-left: 10px;
}
.el-image {
  max-width: 100px;
}
</style>