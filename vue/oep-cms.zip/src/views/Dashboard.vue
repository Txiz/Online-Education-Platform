<template>
  <div>
    <el-row :gutter="20">
      <el-col :span="12" style="height:855px">
        <el-card style="height:100%">
          <div slot="header" class="clearfix" >
            <span>用户信息</span>
            <el-button
              style="float: right; padding: 3px 0"
              type="text"
              @click="passwordDialogVisible = true"
              >修改密码</el-button
            >
          </div>
          <el-form :model="currentUser" label-position="top">
            <el-form-item label="用户头像">
              <el-upload
                class="avatar-uploader"
                action="#"
                :http-request="uploadAvatar"
              >
                <i
                  class="el-icon-plus avatar-uploader-icon"
                  v-if="!currentUser.avatar"
                />
                <el-image
                  v-else
                  :src="currentUser.avatar"
                  class="avatar"
                ></el-image>
              </el-upload>
            </el-form-item>
            <el-form-item label="用户账号" prop="username">
              <el-input v-model="currentUser.username"></el-input>
            </el-form-item>
            <el-form-item label="用户姓名" prop="description">
              <el-input v-model="currentUser.description"></el-input>
            </el-form-item>
            <el-form-item label="角色列表">
                <el-tag
                  v-for="role in currentUser.roles"
                  :key="role.roleId"
                >
                  {{ role.roleName }}
                </el-tag>
            </el-form-item>
            <el-button type="primary" @click="updateUser">修改</el-button>
          </el-form>
        </el-card>
      </el-col>
      <el-col :span="12" style="height:855px">
        <el-card style="height:100%">
          <div slot="header" class="clearfix">
            <span>项目信息</span>
            <el-button
              style="float: right; padding: 3px 0"
              type="text"
              @click="
                getPage('https://gitee.com/Txiz/Online-Education-Platform')
              "
              >获取源码</el-button
            >
          </div>
          <el-table border :data="transData">
            <el-table-column
              v-for="(item, index) in transTitle"
              :label="item"
              :key="index"
              align="center"
            >
              <template slot-scope="scope">
                {{ scope.row[index] }}
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>
    <!--修改用户密码对话框-->
    <el-dialog
      title="修改当前用户密码"
      width="50%"
      :visible.sync="passwordDialogVisible"
      :close-on-click-modal="false"
      @close="passwordDialogClosed"
    >
      <el-form
        :model="passwordForm"
        ref="passwordFormRef"
        label-width="80px"
        :rules="passwordFormRules"
      >
        <el-form-item label="原密码" prop="op">
          <el-input v-model="passwordForm.op" show-password></el-input>
        </el-form-item>
        <el-form-item label="新密码" prop="np" show-password>
          <el-input v-model="passwordForm.np"></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="cp" show-password>
          <el-input v-model="passwordForm.cp"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="passwordDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="updatePassword">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import User from "@/api/admin/user";
import Oss from "@/api/oss/oss";

export default {
  name: "Dashboard",
  data() {
    return {
      currentUser: new Object(),
      currentDate: new Date(),
      passwordDialogVisible: false,
      passwordForm: {
        op: "",
        np: "",
        cp: "",
      },
      passwordFormRules: {
        op: [{ required: true, message: "请输入原密码", trigger: "blur" }],
        np: [{ required: true, message: "请输入新密码", trigger: "blur" }],
        cp: [{ required: true, message: "请再次输入新密码", trigger: "blur" }],
      },
      // originData 为原始正常的数据, 此数据按正常表格展示 一行一行的数据
      // 保证数组里每一个对象中的字段顺序, 从上到下 一次对应显示表格中的从左到右
      originData: [
        {
          author: "熊兆熙，徐嘉怡，程佳禾",
          version: "1.0 Version",
          frame: "SpringCloud + Vue",
          time: "2021年4月13日",
          position: "在线教育平台管理系统",
        },
      ],
      originTitle: ["项目作者", "当前版本", "基于框架", "开发时间", "产品定位"], // originTitle 该标题为 正常显示的标题, 数组中的顺序就是上面数据源对象中的字段标题对应的顺序
      transTitle: ["项目信息", "星超尔雅在线教育平台"], // transTitle 该标题为转化后的标题
      transData: [],
      user: {},
    };
  },
  created() {
    this.getCurrentUser();
    // 数组按矩阵思路, 变成转置矩阵
    let matrixData = this.originData.map((row) => {
      let arr = [];
      for (let key in row) {
        arr.push(row[key]);
      }
      return arr;
    });
    // 加入标题拼接最终的数据
    this.transData = matrixData[0].map((col, i) => {
      return [
        this.originTitle[i],
        ...matrixData.map((row) => {
          return row[i];
        }),
      ];
    });
  },
  methods: {
    goTo(url) {
      window.open("about:blank").location.href = url;
    },
    getCurrentUser() {
      User.getCurrentUser().then((res) => {
        if (res.code === 20000) {
          this.currentUser = res.data.currentUser;
        }
      });
    },
    updateUser() {
      this.user.userId = this.currentUser.userId
      this.user.username= this.currentUser.username
      this.user.description =this.currentUser.description
      this.user.avatar = this.currentUser.avatar
      User.updateCurrentUser(this.user).then((res) => {
        if (res.code === 20000) {
          window.sessionStorage.clear();
          this.msgSuccess(res.message);
          this.$router.replace("/login");
        }
      });
    },
    updatePassword() {
      this.$refs.passwordFormRef.validate((valid) => {
        if (valid) {
          User.updatePassword(this.passwordForm).then((res) => {
            if (res.code === 20000) {
              this.passwordDialogClosed();
              window.sessionStorage.clear();
              this.msgSuccess(res.message);
              this.$router.replace("/login");
            }
          });
        }
      });
    },
    // 关闭修改密码对话框
    passwordDialogClosed() {
      this.$refs.passwordFormRef.resetFields();
    },
    uploadAvatar(param) {
      let fd = new FormData();
      fd.append("file", param.file);
      Oss.uploadFile(fd).then((res) => {
        if (res.code === 20000) {
          this.currentUser.avatar = res.data.url;
        }
      });
    },
    getPage(url) {
      window.open("about:blank").location.href = url;
    },
  }
};
</script>

<style scoped>
.el-row {
  margin-bottom: 20px;
}
.el-col {
  border-radius: 4px;
}
.el-image {
  max-width: 100px;
}
</style>