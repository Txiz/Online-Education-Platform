<template>
  <div>
    <!-- 面包屑导航 -->
    <Breadcrumb parentTitle="日志管理" />
    <el-card>
    <el-tabs type="card">
      <el-tab-pane :lazy='true'>
        <span slot="label"><i class="el-icon-document-checked"></i>&nbsp;登录日志</span>
        <LoginLog />
      </el-tab-pane>
      <el-tab-pane :lazy='true'>
        <span slot="label"><i class="el-icon-document-remove"></i>&nbsp;操作日志</span>
        <OperateLog />
      </el-tab-pane>
      <el-tab-pane :lazy='true'>
        <span slot="label"><i class="el-icon-document-delete"></i>&nbsp;异常日志</span>
        <ExceptionLog />
      </el-tab-pane>
    </el-tabs>
    </el-card>
  </div>
</template>

<script>
import Breadcrumb from "@/components/Breadcrumb"
import LoginLog from '@/components/log/LoginLog'
import OperateLog from '@/components/log/OperateLog'
import ExceptionLog from '@/components/log/ExceptionLog'

export default {
  name: "Log",
  components: {
    Breadcrumb,
    LoginLog,
    OperateLog,
    ExceptionLog
  },
}
</script>

<style scoped>

</style>