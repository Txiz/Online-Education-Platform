<template>
  <div>
    <!-- 面包屑导航 -->
    <Breadcrumb parentTitle="统计管理" />
    <el-row :gutter="20" style="margin-bottom:20px">
      <el-col :span="8">
        <el-card>
          <div slot="header" class="clearfix">
            <span>登录人数</span>
          </div>
            {{ loginNum }}
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card>
          <div slot="header" class="clearfix">
            <span>注册人数</span>
          </div>
            {{ registerNum }}
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card>
          <div slot="header" class="clearfix">
            <span>发生异常</span>
          </div>
            {{ exceptionNum }}
        </el-card>
      </el-col>
    </el-row>
    <el-card style="margin-bottom:20px">
      <!-- TODO 折线图-->
      <div class="chart-container">
        <div id="chart" class="chart" style="width:100%;height:500px" />
      </div>
    </el-card>
    <!-- 操作日志列表 -->
    <el-card>
    <el-table
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
      :data="statisticsList"
      row-key="statisticsId"
    >
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="用户名称" prop="statisticsDate"></el-table-column>
      <el-table-column label="统计当日登录人数" prop="loginNum"></el-table-column>
      <el-table-column label="统计当日注册人数" prop="registerNum"></el-table-column>
      <el-table-column label="统计当日新增异常" prop="exceptionNum"></el-table-column>
      <el-table-column label="创建时间">
        <template v-slot="scope">{{
          scope.row.createTime | dateFormat
        }}</template>
      </el-table-column>
      <el-table-column label="操作" fixed="right">
        <template v-slot="scope">
          <el-button
            class="table_button"
            type="danger"
            icon="el-icon-delete"
            circle
            @click="deleteById(scope.row.statisticsId)"
          ></el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页插件-->
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="page"
      :page-sizes="[50, 100, 200]"
      :page-size="size"
      :total="total"
      layout="total, sizes, prev, pager, next, jumper"
      background
    >
    </el-pagination>
    </el-card>
  </div>
</template>

<script>
import Breadcrumb from "@/components/Breadcrumb"
import Statistics from '@/api/extension/statistics'
import echarts from 'echarts'

export default {
  name: "Statistics",
  components: {
    Breadcrumb,
  },
  data() {
    return {
      statisticsList: [],
      total: 0,
      page: 1,
      size: 50,
      loading: true,
      loginNum: 0,
      registerNum: 0,
      exceptionNum: 0,
      xData:[],
      yData1:[],
      yData2:[],
      yData3:[]
    };
  },
  created() {
    this.loading = true
    this.pageStatistics()
    this.getCurrentStatisticsNum()
    this.loading = false
  },
  mounted(){
    this.getStatisticsDataForMap()
  },
  methods: {
    pageStatistics(page = 1) {
      this.page = page;
      Statistics.pageStatistics(this.page, this.size).then((res) => {
        if (res.code === 20000) {
          this.msgSuccess(res.message);
          this.statisticsList = res.data.statisticsList;
          this.total = res.data.total;
        }
      });
    },
    deleteById(statisticsId) {
      this.$confirm("此操作将删除该标签，是否删除?", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(() => {
        Statistics.deleteById(statisticsId).then((res) => {
          if (res.code === 20000) {
            this.msgSuccess(res.message);
            this.pageStatistics();
          }
        });
      });
    },
    // 分页插件，监听size改变事件
    handleSizeChange(newSize) {
      this.size = newSize;
      this.pageStatistics();
    },
    // 分页插件，监听page改变的事件
    handleCurrentChange(newPage) {
      this.page = newPage;
      this.pageStatistics(this.page);
    },
    getCurrentStatisticsNum(){
      Statistics.getCurrentStatisticsNum()
        .then(res => {
          if(res.code === 20000){
            this.loginNum = res.data.loginNum
            this.registerNum = res.data.registerNum
            this.exceptionNum = res.data.exceptionNum
          }
        })
    },
    getStatisticsDataForMap(){
      Statistics.getStatisticsDataForMap()
        .then(res => {
          if(res.code === 20000){
            this.xData = res.data.date
            this.yData1 = res.data.loginNums
            this.yData2 = res.data.registerNums
            this.yData3 = res.data.exceptionNums
            this.setChart()
          }
        })
    },
    setChart() {
      console.log()
      let mychart = echarts.init(document.getElementById('chart'))
      var option = {
        title: {
            text: '最近十四天的统计数据（每日0时5分更新）'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
          data: ['登录人数','注册人数','异常数目']
        },
        toolbox: {
          feature: {
              saveAsImage: {}
          }
        },
        xAxis: {
            type: 'category',
            data: this.xData
        },
        yAxis: {
            type: 'value'
        },
        series: [
          {
            name: '登录人数',
            data: this.yData1,
            type: 'line'
          },
          {
            name: '注册人数',
            data: this.yData2,
            type: 'line'
          },
          {
            name: '异常数目',
            data: this.yData3,
            type: 'line'
          }
        ]
      }
      mychart.setOption(option)
    },
  }
};
</script>

<style scoped>
.table_button {
  margin-left: 10px;
}
</style>