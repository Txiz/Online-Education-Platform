<template>
  <div>
    <!-- 面包屑导航 -->
    <Breadcrumb parentTitle="轮播图管理"/>
    <el-card class="box-card">
    <!-- 走马灯 -->
    <el-carousel height="500px">
      <el-carousel-item v-for="item in bannerList" :key="item.bannerId">
        <el-image
          :src="item.bannerUrl">
        </el-image>
      </el-carousel-item>
    </el-carousel>
    </el-card>
    <el-card class="box-card">
    <!-- 功能按钮 -->
    <el-upload
      class="upload-demo"
      action="#"
      :http-request="savePicture">
      <el-button type="primary" icon="el-icon-plus">添加</el-button>
    </el-upload>
    <!-- 分类列表 -->
    <el-table :data="bannerList" row-key="bannerId">
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="轮播图" width="150">
        <template v-slot="scope">
          <el-image
            :src="scope.row.bannerUrl"
            fit="cover">
          </el-image>
        </template>
      </el-table-column>
      <el-table-column label="创建时间">
        <template v-slot="scope">{{ scope.row.createTime | dateFormat }}</template>
      </el-table-column>
      <el-table-column label="操作" fixed="right" width="80">
        <template v-slot="scope">
          <el-button class="table_button" type="danger" icon="el-icon-delete" circle @click="deleteBannerById(scope.row.bannerId)"></el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页插件-->
    <el-pagination 
      @size-change="handleSizeChange" 
      @current-change="handleCurrentChange" 
      :current-page="page"
      :page-sizes="[10, 20, 50]" 
      :page-size="size" 
      :total="total"
      layout="total, sizes, prev, pager, next, jumper" 
      background>
    </el-pagination>
    </el-card>
  </div>
</template>

<script>
import Breadcrumb from "@/components/Breadcrumb"
import Banner from '@/api/extension/banner'
import Oss from '@/api/oss/oss'

export default {
  name: "Banner",
  components: {
    Breadcrumb
  },
  data() {
    return {
      bannerList: [],
      total:0,
      page: 1,
      size: 10,
      saveForm: { bannerUrl: '' },
    }
  },
  created() {
    this.pageBanner()
  },
  methods :{
    // 保存轮播图
    saveBanner(){
      Banner.saveBanner(this.saveForm)
        .then(res => {
          if(res.code===20000){
            this.msgSuccess(res.message)
            this.pageBanner()
          }
        })
    },
    // 分页查询轮播图
    pageBanner(page=1){
      this.page=page
      Banner.pageBanner(this.page,this.size)
        .then(res=>{
          if(res.code===20000){
            this.msgSuccess(res.message)
            this.bannerList = res.data.bannerList
            this.total = res.data.total
          }
        })
    },
    deleteBannerById(){
      this.$confirm('此操作将删除该标签，是否删除?',{
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning',
          }).then(() => {
        Banner.deleteById(bannerId)
          .then(res => {
            if (res.code === 20000) {
              this.msgSuccess(res.message)
              this.pageBanner()
            }
        })
      })
    },
    // 分页插件，监听size改变事件
    handleSizeChange(newSize) {
      this.size = newSize
      this.pageUser()
    },
    // 分页插件，监听page改变的事件
    handleCurrentChange(newPage) {
      this.page = newPage
      this.pageUser(this.page)
    },
    // 上传组件
    savePicture(param){
      let fd=new FormData();
      fd.append("file",param.file)
      Oss.uploadFile(fd)
        .then(res=>{
          console.log(res)
          if(res.code===20000){
            this.msgSuccess(res.message)
            this.saveForm.bannerUrl = res.data.url
            this.saveBanner()
          }
        })
    },
  }
}
</script>

<style scoped>
  .table_button {
    margin-left: 10px;
  }
</style>