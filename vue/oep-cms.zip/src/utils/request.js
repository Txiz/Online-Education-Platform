import axios from "axios";
import { Message } from 'element-ui'

const request = axios.create({
	baseURL: '/baseURL',
	timeout: 20000,
})

request.interceptors.response.use(success => {
  // 如果前端成功的调到了接口
  if(success.status && success.status  == 200){
    // 后端接口响应成功会给20000
    if(success.data.code != 20000){
      Message.error({
        message: success.data.message
      })
      return
    }
  }
  return success.data
}, error=>{
  Message.error({
    message: '未知错误!'
  })
  return
})

request.interceptors.request.use(config => {
  // 存在token，请求则携带token
  if(window.sessionStorage.getItem('token')){
    config.headers['Authorization'] = window.sessionStorage.getItem('token')
  }
  return config
})

export default request