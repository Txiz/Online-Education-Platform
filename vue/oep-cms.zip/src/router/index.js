import Vue from 'vue'
import VueRouter from 'vue-router'
import Main from '@/components/Main'

Vue.use(VueRouter)

const routes = [
  {
    path: '/login',
    component: () => import('@/views/Login')
  },
  {
    path: '/',
    component: Main,
    redirect: '/dashboard',
    children: [
      {
        path : '/dashboard',
        component: () => import('@/views/Dashboard'),
      },
      {
        path: '/user',
        component: () => import('@/views/admin/User')
      },
      {
        path: '/role',
        component: () => import('@/views/admin/Role')
      },
      {
        path : '/menu',
        component: () => import('@/views/admin/Menu'),
      },
      {
        path: '/api',
        component: () => import('@/views/admin/Api')
      },
      {
        path : '/comment',
        component: () => import('@/views/education/Comment'),
      },
      {
        path : '/course',
        component: () => import('@/views/education/Course'),
      },
      {
        path : '/people',
        component: () => import('@/views/education/People'),
      },
      {
        path: '/category',
        component: () => import('@/views/education/Category')
      },
      {
        path: '/log',
        component: () => import('@/views/extension/Log')
      },
      {
        path : '/banner',
        component: () => import('@/views/extension/Banner')
      },
      {
        path : '/statistics',
        component: () => import('@/views/extension/Statistics')
      }
    ]
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})


//挂载路由导航守卫
router.beforeEach((to,from,next) => {
  if(to.path !== '/login') {
    const tokenStr = window.sessionStorage.getItem('token')
    if(!tokenStr){
      next('/login')
    }
  }
  next()
})

export default router
