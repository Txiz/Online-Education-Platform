<template>
  <div>
    <!-- 添加章节-->
    <el-button
      type="primary"
      icon="el-icon-plus"
      @click="saveDialogVisible = true"
      >添加</el-button
    >
    <!-- 章节列表 -->
    <el-table
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
      :data="chapterList"
      row-key="chapterId"
      default-expand-all
      :tree-props="{ children: 'children', hasChildren: true }"
    >
      <el-table-column
        label="章节名称"
        prop="chapterName"
        min-width="140"
      ></el-table-column>
      <el-table-column label="视频凭证" prop="videoUrl"></el-table-column>
      <el-table-column label="视频名称" prop="videoName" min-width="90"></el-table-column>
      <el-table-column label="创建时间" min-width="100">
        <template v-slot="scope">
          {{ scope.row.createTime | dateFormat }}
        </template>
      </el-table-column>
      <el-table-column label="更新时间" min-width="100">
        <template v-slot="scope">
          {{ scope.row.updateTime | dateFormat }}
        </template>
      </el-table-column>
      <el-table-column label="操作" fixed="right" min-width="180">
        <template v-slot="scope">
          <el-button
            class="table_button"
            type="primary"
            icon="el-icon-edit"
            circle
            @click="show(scope.row)"
          ></el-button>
          <el-button
            class="table_button"
            type="danger"
            icon="el-icon-delete"
            circle
            @click="deleteChapterById(scope.row.chapterId)"
          ></el-button>
          <el-button
            class="table_button"
            type="success"
            icon="el-icon-view"
            circle
            @click="showVideo(scope.row)"
            :disabled="scope.row.parentId ? false : true"
          ></el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页插件-->
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="page"
      :page-sizes="[20, 50, 100]"
      :page-size="size"
      :total="total"
      layout="total, sizes, prev, pager, next, jumper"
      background
    >
    </el-pagination>
    <!--添加章节对话框-->
    <el-dialog
      v-if="saveDialogVisible"
      title="添加章节"
      width="50%"
      :visible.sync="saveDialogVisible"
      :close-on-click-modal="false"
      @close="saveDialogClosed"
      append-to-body
    >
      <el-form
        :model="saveForm"
        ref="saveFormRef"
        label-width="80px"
        :rules="saveFormRules"
      >
        <el-form-item label="父章节">
          <el-select v-model="saveForm.parentId" placeholder="请选择父章节">
            <el-option label="选择此项，创建父章节" :value="0"></el-option>
            <el-option
              v-for="item in parentChapter"
              :key="item.chapterId"
              :label="item.chapterName"
              :value="item.chapterId"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="章节名称" prop="chapterName">
          <el-input v-model="saveForm.chapterName"></el-input>
        </el-form-item>
        <el-form-item label="上传视频">
          <el-upload
            class="upload-demo"
            action="#"
            :http-request="saveUploadVideo"
          >
            <el-button type="warning" icon="el-icon-upload">上传视频</el-button>
          </el-upload>
        </el-form-item>
        <el-form-item label="视频凭证" prop="videoUrl">
          <el-input v-model="saveForm.videoUrl" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="视频名称" prop="videoName">
          <el-input v-model="saveForm.videoName"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="saveDialogClosed">取 消</el-button>
        <el-button type="primary" @click="saveChapter">确 定</el-button>
      </span>
    </el-dialog>
    <!--更新章节对话框-->
    <el-dialog
      v-if="updateDialogVisible"
      title="编辑章节"
      width="50%"
      :visible.sync="updateDialogVisible"
      :close-on-click-modal="false"
      @close="updateDialogClosed"
      append-to-body
    >
      <!--内容主体-->
      <el-form
        :model="updateForm"
        ref="updateFormRef"
        label-width="80px"
        :rules="updateFormRules"
      >
        <el-form-item label="章节名称" prop="chapterName">
          <el-input v-model="updateForm.chapterName"></el-input>
        </el-form-item>
        <el-form-item label="上传视频" v-if="updateForm.parentId">
          <el-upload
            class="upload-demo"
            action="#"
            :http-request="updateUploadVideo"
          >
            <el-button type="warning" icon="el-icon-upload">上传视频</el-button>
          </el-upload>
        </el-form-item>
        <el-form-item
          label="视频凭证"
          prop="videoUrl"
          v-if="updateForm.parentId"
        >
          <el-input v-model="updateForm.videoUrl" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item
          label="视频名称"
          prop="videoName"
          v-if="updateForm.parentId"
        >
          <el-input v-model="updateForm.videoName"></el-input>
        </el-form-item>
      </el-form>
      <!--底部-->
      <span slot="footer">
        <el-button @click="updateDialogClosed">取 消</el-button>
        <el-button type="primary" @click="updateChapter">确 定</el-button>
      </span>
    </el-dialog>
    <!--观看视频对话框-->
    <el-dialog
      v-if="videoDialogVisible"
      :title="showVideoForm.videoName"
      width="75%"
      :visible.sync="videoDialogVisible"
      :close-on-click-modal="false"
      @close="videoDialogClosed"
      append-to-body>
      <Video :videoUrl="showVideoForm.videoUrl" :playAuth="showVideoForm.videoPlayAuth" v-if="videoDialogVisible" />
    </el-dialog>
  </div>
</template>

<script>
import Chapter from "@/api/education/chapter";
import Video from "@/components/Video";
import Vod from "@/api/vod/vod";

export default {
  name: "chapter",
  props: {
    courseId: {
      type: Number,
      required: true,
    },
  },
  components: {
    Video,
  },
  data() {
    return {
      chapterList: [],
      parentChapter: [],
      total: 0,
      page: 1,
      size: 20,
      saveDialogVisible: false,
      updateDialogVisible: false,
      videoDialogVisible: false,
      saveForm: {},
      updateForm: {},
      showVideoForm: {
        playAuth: ''
      },
      saveFormRules: {
        chapterName: [
          { required: true, message: "请输入章节名称", trigger: "blur" },
        ],
        videoName: [
          { required: true, message: "请输入视频名称", trigger: "blur" },
        ],
      },
      updateFormRules: {
        chapterName: [
          { required: true, message: "请输入章节名称", trigger: "blur" },
        ],
        videoName: [
          { required: true, message: "请输入视频名称", trigger: "blur" },
        ],
      },
      loading: true,
    };
  },
  created() {
    this.loading = true;
    this.pageChapter();
    this.loading = false;
  },
  mounted() {
    this.listAllParentChapter();
  },
  methods: {
    pageChapter(page = 1) {
      this.page = page;
      Chapter.pageChapter(this.courseId, this.page, this.size).then((res) => {
        if (res.code === 20000) {
          this.msgSuccess(res.message);
          this.chapterList = res.data.chapterList;
          this.total = res.data.total;
        }
      });
    },
    listAllParentChapter() {
      Chapter.listAllParentChapter(this.courseId).then((res) => {
        if (res.code === 20000) {
          this.msgSuccess(res.message);
          this.parentChapter = res.data.parentChapter;
        }
      });
    },
    show(row) {
      //row中没有对象
      //直接拓展运算符深拷贝一份(拓展运算符不能深拷贝对象，只能拷贝引用)
      //如果直接赋值，则为引用，表格上的数据也会随对话框中数据的修改而实时改变
      this.updateForm = { ...row };
      this.updateDialogVisible = true;
    },
    showVideo(row) {
      this.showVideoForm = { ...row };
      if(this.showVideoForm.videoUrl)
        this.videoDialogVisible = true;
      else{
        this.$message({
          message: 'videoUrl为空!，无法播放视频，请上传视频',
          type: 'warning'
        });
      }
    },
    saveChapter() {
      this.$refs.saveFormRef.validate((valid) => {
        if (valid) {
          this.saveForm.courseId = this.courseId;
          Chapter.saveOrUpdateChapter(this.saveForm).then((res) => {
            if (res.code === 20000) {
              this.msgSuccess(res.message);
              this.saveForm = {};
              this.saveDialogClosed();
              this.pageChapter();
            }
          });
        }
      });
    },
    updateChapter() {
      this.$refs.updateFormRef.validate((valid) => {
        if (valid) {
          Chapter.saveOrUpdateChapter(this.updateForm).then((res) => {
            if (res.code === 20000) {
              this.msgSuccess(res.message);
              this.updateDialogVisible = false;
              this.pageChapter();
            }
          });
        }
      });
    },
    // 根据章节id删除章节
    deleteChapterById(chapterId) {
      this.$confirm("此操作将删除该标签，是否删除?", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(() => {
        Chapter.deleteChapterById(chapterId).then((res) => {
          if (res.code === 20000) {
            this.msgSuccess(res.message);
            this.pageChapter();
          }
        });
      });
    },
    // 分页插件，监听size改变事件
    handleSizeChange(size) {
      this.size = size;
      this.pageChapter();
    },
    // 分页插件，监听page改变的事件
    handleCurrentChange(page) {
      this.page = page;
      this.pageChapter(this.page);
    },
    // 关闭添加章节对话框
    saveDialogClosed() {
      this.saveForm = {};
      this.$refs.saveFormRef.resetFields();
      this.saveDialogVisible = false;
    },
    // 关闭编辑章节对话框
    updateDialogClosed() {
      this.$refs.updateFormRef.resetFields();
      this.updateDialogVisible = false;
    },
    // 关闭视频播放对话框
    videoDialogClosed() {},
    // 上传组件——上传视频
    saveUploadVideo(param) {
      let fd = new FormData();
      fd.append("file", param.file);
      Vod.upload(fd).then((res) => {
        if (res.code === 20000) {
          this.msgSuccess(res.message);
          this.saveForm.videoUrl = res.data.videoUrl;
        }
      });
    },
    updateUploadVideo(param) {
      let fd = new FormData();
      fd.append("file", param.file);
      Vod.upload(fd).then((res) => {
        if (res.code === 20000) {
          this.msgSuccess(res.message);
          this.updateForm.videoUrl = res.data.videoUrl;
        }
      });
    },
  },
};
</script>

<style scoped>
.table_button {
  margin-left: 10px;
}
</style>