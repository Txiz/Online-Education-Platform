<template>
  <el-container class="home-container">
    <!--头部-->
    <el-header>
      <div class="title">
        <img src="../assets/img/logo.png" alt="" height="60" />
      </div>
      <el-dropdown trigger="click" @command="dropdownHandler">
        <div class="el-dropdown-link">
          <el-avatar
            shape="circle"
            :size="45"
            fit="contain"
            :src="currentUser.avatar"
          ></el-avatar>
        </div>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item icon="ali-iconfont el-icon-s-custom" command="info"
            >个人信息</el-dropdown-item
          >
          <el-dropdown-item icon="ali-iconfont icon-logout" command="logout"
            >退出登录</el-dropdown-item
          >
        </el-dropdown-menu>
      </el-dropdown>
    </el-header>
    <!--页面主体-->
    <el-container>
      <!--侧边栏-->
      <el-aside :width="isCollapse ? '64px' : '190px'">
        <div class="toggle-button" @click="isCollapse = !isCollapse">
          <i :class="isCollapse ? 'el-icon-s-unfold' : 'el-icon-s-fold'"></i>
        </div>
        <!--菜单-->
        <el-menu
          background-color="#333744"
          text-color="#fff"
          active-text-color="#409eff"
          :unique-opened="false"
          :collapse="isCollapse"
          :collapse-transition="false"
          :router="true"
          :default-active="$store.state.activePath"
          :default-openeds="['0','1','2','3','4','5','6']"
        >
          <el-menu-item index="/dashboard">
            <i class="el-icon-price-tag"></i>
            <span>仪表盘</span>
          </el-menu-item>
          <!-- 一级菜单 -->
          <el-submenu
            :index="menu.menuId+''"
            v-for="menu in menuList"
            :key="menu.menuId"
          >
            <!-- 一级菜单的模板区域 -->
            <template slot="title">
              <i :class="menu.icon"></i>
              <span>{{ menu.menuName }}</span>
            </template>
            <!-- 二级菜单 -->
            <el-menu-item
              :index="subMenu.path"
              v-for="subMenu in menu.children"
              :key="subMenu.menuId"
            >
              <template slot="title">
                <i :class="subMenu.icon"></i>
                <span>{{ subMenu.menuName }}</span>
              </template>
            </el-menu-item>
          </el-submenu>
        </el-menu>
      </el-aside>
      <!--右侧内容主体-->
      <el-main
        :class="isCollapse ? 'm-el-main-width-64' : 'm-el-main-width-190'"
      >
        <!--加 key 让组件被重用时 重新执行生命周期 否则在编辑文章页面路由到写文章页面时 数据被重用-->
        <router-view :key="$route.fullPath" />
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import Menu from "@/api/admin/menu";
import User from "@/api/admin/user";
import Index from "@/api/admin/index";

export default {
  name: "Main",
  data() {
    return {
      menuList: [],
      currentUser: [],
      isCollapse: false,
    };
  },
  created() {
    this.getCurrentUser();
    this.getMenusByUserId();
    
  },
  mounted() {

  },
  methods: {
    getCurrentUser() {
      User.getCurrentUser().then((res) => {
        if (res.code === 20000) {
          this.currentUser = res.data.currentUser;
			    this.open();
        }
      });
    },
    getMenusByUserId() {
      Menu.getMenusByUserId().then((res) => {
        if (res.code === 20000) {
          this.menuList = res.data.menuList;
        }
      });
    },
    open() {
      this.$notify({
        title: "登录成功",
        message: "welcome，"+this.currentUser.username,
        offset: 50,
		    type: 'success'
      });
    },
    // 下拉菜单
    dropdownHandler(command) {
      if (command === "logout") {
        Index.logout().then((res) => {
          if (res.code === 20000) {
            window.sessionStorage.clear();
            this.msgSuccess(res.message);
            this.$router.replace("/login");
          }
        });
      }
      if (command === "info" && this.$route.path !== "/") {
        this.$router.push("/");
      }
    },
  },
};
</script>

<style scoped>
.el-aside {
  -ms-overflow-style: none; /* IE10 */
  scrollbar-width: none; /* Firefox */
}

.el-aside::-webkit-scrollbar {
  display: none;
}

.el-main::-webkit-scrollbar {
  width: 8px;
  height: 5px;
}

.el-main::-webkit-scrollbar-thumb {
  -webkit-box-shadow: inset 0 0 6px #48dbfb;
  box-shadow: inset 0 0 6px #48dbfb;
  background-color: #48dbfb;
}

.el-main::-webkit-scrollbar-track {
  -webkit-box-shadow: inset 0 0 6px transparent;
  box-shadow: inset 0 0 6px transparent;
  background-color: transparent;
}

.el-main::-webkit-scrollbar-track-piece {
  background-color: transparent;
}

.home-container {
  height: 100%;
}

.el-header {
  background-color: #373d41;
  display: flex;
  justify-content: space-between;
  padding-left: 10px;
  align-items: center;
  color: #ffffff;
  font-size: 22px;
  user-select: none;
}

.el-header div {
  display: flex;
  align-items: center;
}

.el-header .title span {
  margin-left: 15px;
}

.el-dropdown-link {
  outline-style: none !important;
  outline-color: unset !important;
  height: 100%;
  cursor: pointer;
}

.el-dropdown-menu {
  margin: 7px 0 0 0 !important;
  padding: 0 !important;
  border: 0 !important;
}

.el-aside {
  background-color: #333744;
  position: absolute;
  top: 60px;
  bottom: 0;
  user-select: none;
}

.el-aside .el-menu {
  border-right: none;
}

.el-submenu .el-menu-item {
  min-width: inherit;
}

.el-main {
  background-color: #eaedf1;
  position: absolute;
  top: 60px;
  bottom: 0;
  right: 0;
  overflow-y: auto;
  overflow-x: hidden;
}

.m-el-main-width-190 {
  width: calc(100% - 190px);
}

.m-el-main-width-64 {
  width: calc(100% - 64px);
}

.iconfont {
  margin-right: 20px;
  font-size: 20px;
}

.submenu.ali-iconfont {
  vertical-align: middle;
  margin-right: 5px;
  width: 24px;
  text-align: center;
  display: inline-block;
}

.toggle-button {
  background-color: #4a5064;
  font-size: 20px;
  line-height: 40px;
  color: #ffffff;
  text-align: center;
  cursor: pointer;
}
</style>