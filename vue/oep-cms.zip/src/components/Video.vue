<template>
  <div>
    <!-- 定义播放器dom -->
    <div class="prism-player" id="player"></div>
  </div >
</template>

<script>

export default {
  name: "Video",
  props: {
    videoUrl: {
      type: String,
      required: true,
    },
    playAuth: {
      type: String,
      required: true,
    }
  },
  mounted() {
    new Aliplayer({
      "id": "player",
      "vid": this.videoUrl,
      "playauth": this.playAuth,
      "qualitySort": "asc",
      "format": "mp4",
      "mediaType": "video",
      "width": "100%",
      "height": "500px",
      "autoplay": true,
      "isLive": false,
      "rePlay": false,
      "playsinline": true,
      "preload": true,
      "controlBarVisibility": "hover",
      "useH5Prism": true
      }, function (player) {
      console.log("The player is created")
    });
  },
}
</script>

<style scoped>

</style>