<template>
	<el-breadcrumb separator-class="el-icon-arrow-right">
		<el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
		<el-breadcrumb-item>{{ parentTitle }}</el-breadcrumb-item>
	</el-breadcrumb>
</template>

<script>
	export default {
		name: "Breadcrumb",
		props: {
			parentTitle: {
				type: String,
				required: false
			}
		},
	}
</script>

<style scoped>
	.el-breadcrumb {
		padding-left:10px
	}
</style>