<template>
  <div>
    <!-- 操作日志列表 -->
    <el-table
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
      :data="logList"
      row-key="logId"
    >
      <el-table-column label="序号" type="index"></el-table-column>
      <el-table-column label="用户名称" prop="username"></el-table-column>
      <el-table-column label="请求接口" prop="uri" min-width="250"></el-table-column>
      <el-table-column label="请求方法" prop="method"></el-table-column>
      <el-table-column label="方法描述" prop="description"></el-table-column>
      <el-table-column
        label="异常信息"
        prop="error"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column label="ip地址" prop="ip"></el-table-column>
      <el-table-column label="ip来源" prop="ipSource"></el-table-column>
      <el-table-column label="操作系统" prop="os"></el-table-column>
      <el-table-column label="浏览器" prop="browser"></el-table-column>
      <el-table-column label="创建时间">
        <template v-slot="scope">
          {{ scope.row.createTime | dateFormat }}
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template v-slot="scope">
          <el-button
            class="table_button"
            type="danger"
            icon="el-icon-delete"
            circle
            @click="deleteByLogId(scope.row.logId)"
          ></el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页插件-->
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="page"
      :page-sizes="[50, 100, 200]"
      :page-size="size"
      :total="total"
      layout="total, sizes, prev, pager, next, jumper"
      background
    >
    </el-pagination>
  </div>
</template>

<script>
import Breadcrumb from "@/components/Breadcrumb";
import ExceptionLog from "@/api/extension/exception-log";

export default {
  name: "ExceptionLog",
  components: {
    Breadcrumb,
  },
  data() {
    return {
      logList: [],
      total: 0,
      page: 1,
      size: 50,
      loading: true,
    };
  },
  created() {
    this.loading = true;
    this.pageExceptionLog();
    this.loading = false;
  },
  methods: {
    pageExceptionLog(page = 1) {
      this.page = page;
      ExceptionLog.pageExceptionLog(this.page, this.size).then((res) => {
        if (res.code === 20000) {
          this.msgSuccess(res.message);
          this.logList = res.data.logList;
          this.total = res.data.total;
        }
      });
    },
    deleteByLogId(logId) {
      this.$confirm("此操作将删除该标签，是否删除?", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(() => {
        ExceptionLog.deleteByLogId(logId).then((res) => {
          if (res.code === 20000) {
            this.msgSuccess(res.message);
            this.pageExceptionLog();
          }
        });
      });
    },
    // 分页插件，监听size改变事件
    handleSizeChange(newSize) {
      this.size = newSize;
      this.pageExceptionLog();
    },
    // 分页插件，监听page改变的事件
    handleCurrentChange(newPage) {
      this.page = newPage;
      this.pageExceptionLog(this.page);
    },
  },
};
</script>

<style scoped>
.table_button {
  margin-left: 10px;
}
</style>