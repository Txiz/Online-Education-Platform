import request from '@/utils/request' 

export default {
    deleteByLogId(logId){
        return request({
            url: `/extension/operate-log/deleteByLogId/${logId}`,
            method: 'delete',
        })
      },
      pageOperateLog(current,size){
        return request({
          url:`/extension/operate-log/pageOperateLog/${current}/${size}`,
          method: 'post',
        })
      },
}