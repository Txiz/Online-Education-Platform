import request from '@/utils/request' 

export default {
    deleteByLogId(logId){
        return request({
            url: `/extension/login-log/deleteByLogId/${logId}`,
            method: 'delete',
        })
      },
      pageLoginLog(current,size){
        return request({
          url:`/extension/login-log/pageLoginLog/${current}/${size}`,
          method: 'post',
        })
      },
}