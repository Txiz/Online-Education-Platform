import request from '@/utils/request' 

export default {
  deleteByLogId(logId){
    return request({
        url: `/extension/exception-log/deleteByLogId/${logId}`,
        method: 'delete',
    })
  },
  pageExceptionLog(current,size){
    return request({
      url:`/extension/exception-log/pageExceptionLog/${current}/${size}`,
      method: 'post',
    })
  },
}