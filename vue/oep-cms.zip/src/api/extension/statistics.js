import request from '@/utils/request' 

export default {
  getCurrentStatisticsNum(){
    return request({
      url: `/extension/statistics/getCurrentStatisticsNum`,
      method: 'get',
    })
  },
  pageStatistics(page,size){
    return request({
      url: `/extension/statistics/pageStatistics/${page}/${size}`,
      method: 'post'
    })
  },
  deleteById(statisticsId){
    return request({
      url: `/extension/statistics/deleteById/${statisticsId}`,
      method: 'delete'
    })
  },
  getStatisticsDataForMap(){
    return request({
      url: `/extension/statistics/getStatisticsDataForMap`,
      method: 'get'
    })
  }
}