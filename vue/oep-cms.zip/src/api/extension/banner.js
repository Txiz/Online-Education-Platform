import request from '@/utils/request' 

export default {
  saveBanner(banner){
    return request({
      url: `/extension/banner/saveBanner`,
      method: 'post',
      data: banner
    })
  },
  pageBanner(page,size){
    return request({
      url: `/extension/banner/pageBanner/${page}/${size}`,
      method: 'post'
    })
  },
  deleteById(bannerId){
    return request({
      url: `/extension/banner/deleteById/${bannerId}`,
      method: 'delete'
    })
  }
}