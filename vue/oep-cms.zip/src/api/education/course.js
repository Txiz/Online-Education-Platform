import request from '@/utils/request' 

export default {
    deleteCourseById(courseId){
        return request({
            url: `/education/course/deleteCourseById/${courseId}`,
            method: 'delete',
        })
      },
      pageCourse(peopleName, current, size){
        return request({
          url:`/education/course/pageCourse/${peopleName}/${current}/${size}`,
          method: 'get',
        })
      },
      saveOrUpdateCourse(courseVo){
        return request({
          url:`/education/course/saveOrUpdateCourse`,
          method: 'post',
          data: courseVo
        })
      },
      searchCourse(peopleName, current, size,courseSearchVo){
        return request({
          url:`/education/course/searchCourse/${peopleName}/${current}/${size}`,
          method: 'post',
          data: courseSearchVo
        })
      },
      listAllChildrenCategory(){
        return request({
          url:`/education/course/listAllChildrenCategory`,
          method: 'get',
        })
      },

}