import request from '@/utils/request' 

export default {
    deleteCommentById(commentId){
        return request({
            url: `/education/comment/deleteCommentById/${commentId}`,
            method: 'delete',
        })
      },
      pageComment(current,size){
        return request({
          url:`/education/comment/pageComment/${current}/${size}`,
          method: 'get',
        })
      },
      saveOrUpdateComment(commentVo){
        return request({
          url:`/education/comment/saveOrUpdateComment`,
          method: 'post',
          data: commentVo
        })
      },
}