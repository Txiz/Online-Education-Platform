import request from '@/utils/request' 


export default {
    // 分页查询课程分类列表
    pageCategory(page,size){
      return request({
          url: `/education/category/pageCategory/${page}/${size}`,
          method: 'get'
      })
    },
     // 查询所有父分类
     listAllParentCategory(){
        return request({
          url: `/education/category/listAllParentCategory`,
          method: 'get'
      })
      },
      //查询所有的子分类用于课程选择
      listAllChildrenCategory(){
        return request({
          url: `/education/category/listAllChildrenCategory`,
          method: 'get'
      })
      },
     // 增加或者修改分类
     saveOrUpdateCategory(categoryVo){
        return request({
            url: `/education/category/saveOrUpdateCategory`,
            method: 'post',
            data: categoryVo
        })
      },
      // 根据id删除分类
      deleteCategoryById(categoryId){
        return request({
            url: `/education/category/deleteCategoryById/${categoryId}`,
            method: 'delete',
        })
      },
      //模糊搜索
      searchCategory(page,size,categorySearchVo){
        return request({
          url: `/education/category/searchCategory/${page}/${size}`,
          method:'post',
          data:categorySearchVo
        })
      }
}