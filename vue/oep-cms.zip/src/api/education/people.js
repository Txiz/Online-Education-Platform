import request from '@/utils/request' 

export default {
  //根据账号id删除账号
  deletePeopleById(peopleId){
      return request({
          url: `/education/people/deletePeopleById/${peopleId}`,
          method: 'delete',
      })
  },
  pagePeople(current,size){
    return request({
      url:`/education/people/pagePeople/${current}/${size}`,
      method: 'get',
    })
  },
  saveOrUpdatePeople(people){
    return request({
      url:`/education/people/saveOrUpdatePeople`,
      method: 'post',
      data: people
    })
  },
  //查询所有的教师账号
  listAllTeacher(){
    return request({
      url:`/education/people/listAllTeacher/${1}`,
      method: 'get',
    })
  },
  // 获取当前登录账号名称
  getCurrentPeople() {
    return request({
      url:`/education/people/getCurrentPeople`,
      method: 'get',
    })
  },
  // 模糊搜索账号
  searchPeople(page,size,peopleSearchVo){
    return request({
      url:`/education/people/searchPeople/${page}/${size}`,
      method: 'post',
      data: peopleSearchVo
    })
  },
  // 使用Excel表批量导入账号
  savePeopleByUseExcel(file){
    return request({
      url: `/education/people/savePeopleByUseExcel`,
      method: 'post',
      data: file
    })
  }
}