import request from '@/utils/request' 

export default{
  listAllParentChapter(courseId){
    return request({
      url:`/education/chapter/listAllParentChapter/${courseId}`,
      method: 'get',
    })
  },
  pageChapter(courseId,current,size){
    return request({
      url:`/education/chapter/pageChapter/${courseId}/${current}/${size}`,
      method: 'get',
    })
  },
  deleteChapterById(chapterId){
    return request({
      url:`/education/chapter/deleteChapterById/${chapterId}`,
      method: 'delete',
    })
  },
  saveOrUpdateChapter(chapterVo){
    return request({
      url:`/education/chapter/saveOrUpdateChapter`,
      method: 'post',
      data: chapterVo
    })
  }
}