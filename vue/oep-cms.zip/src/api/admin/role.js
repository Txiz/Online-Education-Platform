import request from '@/utils/request' 


export default {
  // 分页查询角色列表
  pageRole(page,size){
    return request({
        url: `/admin/role/pageRole/${page}/${size}`,
        method: 'get'
    })
  },
  // 查询所有角色
  listAllRole(){
    return request({
      url: `/admin/role/listAllRole`,
      method: 'get'
  })
  },
  // 增加或者修改角色
  saveOrUpdateRole(roleVo){
    return request({
        url: `/admin/role/saveOrUpdateRole`,
        method: 'post',
        data: roleVo
    })
  },
  // 根据角色id删除角色
  deleteRoleById(roleId){
    return request({
        url: `/admin/role/deleteRoleById/${roleId}`,
        method: 'delete',
    })
  },
  // 模糊查询角色
  searchRole(page,size,roleSearchVo){
    return request({
      url: `/admin/role/searchRole/${page}/${size}`,
      method:'post',
      data:roleSearchVo
    })
  },
}