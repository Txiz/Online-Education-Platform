import request from '@/utils/request' 

export default {
  login(loginForm){
    return request({
        url: `/admin/index/login`,
        method: 'post',
        data: loginForm
    })
  },
  logout(){
    return request({
      url: `/admin/index/logout`,
      method: 'post',
  })
  },
  register(vo){
    return request({
      url: `/admin/index/register`,
      method: 'post',
      data: vo
  })
  }
}