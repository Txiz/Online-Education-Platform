import request from '@/utils/request' 


export default {
    // 分页查询用户列表
    pageUser(page,size){
      return request({
          url: `/admin/user/pageUser/${page}/${size}`,
          method: 'get'
      })
    },
    // 增加或者修改用户
    saveOrUpdateUser(userVo){
      return request({
          url: `/admin/user/saveOrUpdateUser`,
          method: 'post',
          data: userVo
      })
    },
    // 修改当前登录用户的密码
    updatePassword(passwordVo){
      return request({
        url: `/admin/user/updatePassword`,
        method: 'post',
        data: passwordVo
      })
    },
    // 根据用户id删除用户
    deleteUserById(userId){
      return request({
          url: `/admin/user/deleteUserById/${userId}`,
          method: 'delete',
      })
    },
    // 模糊查询用户
    searchUser(page,size,userSearchVo){
      return request({
        url: `/admin/user/searchUser/${page}/${size}`,
        method:'post',
        data:userSearchVo
      })
    },
    // 获取当前登录用户
    getCurrentUser(){
      return request({
        url: `/admin/user/getCurrentUser`,
        method:'get',
      })
    },
    // 修改当前用户信息
    updateCurrentUser(currentUser){
      return request({
        url: `/admin/user/updateCurrentUser`,
        method:'post',
        data: currentUser
      })
    }
}