import request from '@/utils/request' 


export default {
    // 分页查询接口列表
    pageApi(page,size){
      return request({
          url: `/admin/api/pageApi/${page}/${size}`,
          method: 'get'
      })
    },
    // 查询所有接口列表
    listAuthApi(){
      return request({
        url: `/admin/api/listAuthApi`,
        method: 'get'
      })
    },
    // 添加接口
    saveOrUpdateApi(api){
      return request({
          url: `/admin/api/saveOrUpdateApi`,
          method: 'post',
          data: api
      })
    },
    // 删除接口
    deleteApiById(apiId){
      return request({
          url: `/admin/api/deleteApiById/${apiId}`,
          method: 'delete',
      })
    },
    searchApi(page,size,apiSearchVo){
      return request({
        url:`/admin/api/searchApi/${page}/${size}`,
        method:'post',
        data:apiSearchVo
      })
    }
}