import request from '@/utils/request' 

export default {
  deleteMenuById(menuId){
    return request({
        url: `/admin/menu/deleteMenuById/${menuId}`,
        method: 'delete',
    })
  },
  getMenusByUserId(){
    return request({
        url: `/admin/menu/getMenusByUserId`,
        method: 'get',
    })
  },
  listAllParentMenu(){
    return request({
      url:`/admin/menu/listAllParentMenu`,
      method: 'get',
    })
  },
  listMenuTree(){
    return request({
      url:`/admin/menu/listMenuTree`,
      method: 'get',
    })
  },
  pageMenu(current,size){
    return request({
      url:`/admin/menu/pageMenu/${current}/${size}`,
      method: 'get',
    })
  },
  saveOrUpdateMenu(menu){
    return request({
      url:`/admin/menu/saveOrUpdateMenu`,
      method: 'post',
      data: menu
    })
  },
  searchMenu(current,size,menuSearchVo){
    return request({
      url:`/admin/menu/searchMenu/${current}/${size}`,
      method: 'post',
      data: menuSearchVo
    })
  },
}