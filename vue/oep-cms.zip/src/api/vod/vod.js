import request from '@/utils/request' 
import { method } from 'lodash'

export default {
    // 视频上传
    upload(file){
      return request({
        url: `/vod/upload`,
        method: 'post',
        data: file
      })
    },
    // 根据视频url获取视频播放凭证
    getPlayAuth(videoUrl){
      return request({
        url: `/vod/getPlayAuth/${videoUrl}`,
        method: 'get'
      })
    },
    // 根据视频url获取视频播放地址
    getPlayInfo(videoUrl){
      return request({
        url: `/vod/getPlayInfo/${videoUrl}`,
        method: 'get'
      })
    }
}