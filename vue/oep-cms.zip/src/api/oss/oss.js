import request from '@/utils/request' 

export default {
    // 图片上传
    uploadFile(file){
        return request({
            url: `/oss/uploadFile`,
            method: 'post',
            data: file
        })
    },
}