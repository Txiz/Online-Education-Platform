import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import './assets/css/base.css'
import './assets/css/icon/iconfont.css'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import './utils/dateTimeFormatUtils.js'
import Pick from 'e-icon-picker'
import 'e-icon-picker/dist/index.css'

Vue.use(ElementUI)
Vue.use(Pick)

Vue.config.productionTip = false

/* 
  预设一个成功消息提示函数
  失败消息提示在axios(request.js)的拦截器里做统一处理
  成功消息不统一处理的原因
  比如修改博客的时候，需要查询分页博客，所有的分类，所有的标签，修改成功提示
  然后统一处理就会连续提醒四次
*/
Vue.prototype.msgSuccess = function (msg) {
	this.$message.success(msg)
}

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
