const path = require('path')
function resolve (dir) {
  return path.join(__dirname, dir)
}

module.exports = {
  devServer: {
    port: 3001,
    proxy: {
      "/baseURL": {
        target: "http://localhost:8100/",
        changeOrigin: true,
        pathRewrite: {
          "^/baseURL": ""
        }
      }
    }
  },
  configureWebpack: {
    resolve: {
      alias: {
        '@': resolve('./src')
      }
    }
  }
}
