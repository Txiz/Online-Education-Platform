import axios from 'axios'
import cookie from 'js-cookie'
// 创建axios实例
const service = axios.create({
  baseURL: 'http://localhost:8100', // api的base_url
  timeout: 20000 // 请求超时时间
})

service.interceptors.request.use(
  config => {
    // 存在token，请求则携带token
    if(cookie.get("token")){
      config.headers['Authorization'] = cookie.get("token")
    }
    return config
  },
  err => {
    return Promise.reject(err)
  }
)
service.interceptors.response.use(success => {
  return success.data
})

export default service