<template>
  <div class="in-wrap">
    <!-- 公共头引入 -->
    <header id="header">
      <section class="container">
        <h1 id="logo">
          <a href="#" title="谷粒学院">
            <img src="~/assets/img/Logo2.png" width="100%" alt="谷粒学院">
          </a>
        </h1>
        <div class="h-r-nsl">
          <ul class="nav" style="padding-top:5px">
            <router-link to="/" tag="li" active-class="current" exact>
              <a>首页</a>
            </router-link>
            <router-link to="/course" tag="li" active-class="current">
              <a>课程</a>
            </router-link>
            <router-link to="/teacher" tag="li" active-class="current">
              <a>名师</a>
            </router-link>
          </ul>
          <!-- / nav -->
          <ul class="h-r-login" style="padding-top:5px">
            <li id="no-login" v-if="!loginInfo.userId">
              <a href="/login" title="登录">
                <em class="icon18 login-icon">&nbsp;</em>
                <span class="vam ml5">登录</span>
              </a>
              |
              <a href="/register" title="注册">
                <span class="vam ml5">注册</span>
              </a>
            </li>
            <li v-if="loginInfo.userId" class="h-r-user" id="is-login-two" >
              <a :href="'/home/'+loginInfo.username" title>
                <span class="vam disIb" id="userName">{{ loginInfo.username}}</span>
              </a>
              <a href="javascript:void(0)" title="退出" @click="logout()" class="ml5">退出</a>
            </li>
            <!-- /未登录显示第1 li；登录后显示第2，3 li -->
          </ul>
        </div>
        <aside class="mw-nav-btn">
          <div class="mw-nav-icon"></div>
        </aside>
        <div class="clear"></div>
      </section>
    </header>
    <!-- /公共头引入 -->
    <nuxt/>
    <!-- 公共底引入 -->
    <footer id="footer">
      <section class="container">
        <div class="b-foot">
          <section class="fl col-7">
            <section class="mr20">
              <section class="b-f-link">
                <span>Github：https://github.com/Txiz/Online-Education-Platform</span>
                <span>Gitee：https://gitee.com/Txiz/Online-Education-Platform</span>
                <span>Email：xiongzhaoxi@qq.com</span>
              </section>
              <section class="b-f-link mt10">
                <span>©2021课程版权均归xxxx所有 这里是备案号**********</span>
              </section>
            </section>
          </section>
          <div class="clear"></div>
        </div>
      </section>
    </footer>
    <!-- /公共底引入 -->
  </div>
</template>
<script>
import "~/assets/css/reset.css"
import "~/assets/css/theme.css"
import "~/assets/css/global.css"
import "~/assets/css/web.css"
import cookie from 'js-cookie'
export default {
  data() {
    return {
        loginInfo: {}
    }
  },
  created(){
    this.getCurrentUser()
  },
  methods: {
    getCurrentUser(){
      var userStr = cookie.get('user')
      if(userStr){
        this.loginInfo = JSON.parse(userStr)
      }
    },
    logout() {
      //清空cookie值
      cookie.set('token','',{domain: 'localhost'})
      cookie.set('user','',{domain: 'localhost'})
      //回到首页面
      window.location.href = "/";
    }
  }
}
</script>