<template>
  <div class="sign">
    <!--表单-->
    <nuxt/>
  </div>
</template>