import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _60951f6e = () => interopDefault(import('..\\pages\\course\\index.vue' /* webpackChunkName: "pages/course/index" */))
const _0484d04a = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _5f08a1be = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _e046e6a4 = () => interopDefault(import('..\\pages\\teacher\\index.vue' /* webpackChunkName: "pages/teacher/index" */))
const _45761e1e = () => interopDefault(import('..\\pages\\course\\_id.vue' /* webpackChunkName: "pages/course/_id" */))
const _e45031a6 = () => interopDefault(import('..\\pages\\home\\_id.vue' /* webpackChunkName: "pages/home/_id" */))
const _1d2fb31e = () => interopDefault(import('..\\pages\\player\\_vid.vue' /* webpackChunkName: "pages/player/_vid" */))
const _10e1e296 = () => interopDefault(import('..\\pages\\teacher\\_id.vue' /* webpackChunkName: "pages/teacher/_id" */))
const _3415f4c4 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/course",
    component: _60951f6e,
    name: "course"
  }, {
    path: "/login",
    component: _0484d04a,
    name: "login"
  }, {
    path: "/register",
    component: _5f08a1be,
    name: "register"
  }, {
    path: "/teacher",
    component: _e046e6a4,
    name: "teacher"
  }, {
    path: "/course/:id",
    component: _45761e1e,
    name: "course-id"
  }, {
    path: "/home/:id?",
    component: _e45031a6,
    name: "home-id"
  }, {
    path: "/player/:vid?",
    component: _1d2fb31e,
    name: "player-vid"
  }, {
    path: "/teacher/:id",
    component: _10e1e296,
    name: "teacher-id"
  }, {
    path: "/",
    component: _3415f4c4,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
