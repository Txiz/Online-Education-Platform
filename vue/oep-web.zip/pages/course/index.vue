<template>
  <div id="aCoursesList" class="bg-fa of">
    <!-- /课程列表 开始 -->
    <section class="container">
      <header class="comm-title">
        <h2 class="fl tac">
          <span class="c-333">全部课程</span>
        </h2>
        <aside class="h-r-search" style="margin:0;padding:0px">
              <label class="h-r-s-box">
                <input type="text" placeholder="输入你想学的课程" v-model="searchParams.keyword">
                <button type="submit" class="s-btn" @click="searchKeyword()">
                  <em class="icon18">&nbsp;</em>
                </button>
              </label>
          </aside>
      </header>
      <section class="c-sort-box">
        <section class="c-s-dl">
          <dl>
            <dt>
              <span class="c-999 fsize14">课程类别</span>
            </dt>
            <dd class="c-s-dl-li">
              <ul class="clearfix">
                <li>
                  <a title="全部" href="#" @click="searchAll()">全部</a>
                </li>
                <li v-for="(item,index) in OneList" :key="index">
                  <a href="#" @click="searchChildren(item.categoryId,index)">{{item.categoryName}}</a>
                </li>
              </ul>
            </dd>
          </dl>
          <dl>
            <dt>
              <span class="c-999 fsize14"></span>
            </dt>
            <dd class="c-s-dl-li">
              <ul class="clearfix">
                <li v-for="(item,index) in TwoList" :key="index">
                  <a href="#" @click="searchCategory(item.categoryId)">{{item.categoryName}}</a>
                </li>
              </ul>
            </dd>
          </dl>
          <div class="clear"></div>
        </section>
        <div class="js-wrap">
          <section class="fr">
            <span class="c-ccc">
              <i class="c-master f-fM">1</i>/
              <i class="c-666 f-fM">1</i>
            </span>
          </section>
          <section class="fl">
            <ol class="js-tap clearfix">
             <li :class="{'current bg-orange':searchParams.publish!=false}">
                <a title="销量" href="javascript:void(0);" @click="searchPublish()">时间
                <span :class="{hide:searchParams.publish==false}">↓</span>
                </a>
              </li>
              <li :class="{'current bg-orange':searchParams.studentNum!=false}">
                <a title="最新" href="javascript:void(0);" @click="searchStudentNum()">学生数
                <span :class="{hide:searchParams.studentNum==false}">↓</span>
                </a>
              </li>
              <li :class="{'current bg-orange':searchParams.commentNum!=false}">
                <a title="价格" href="javascript:void(0);" @click="searchCommentNum()">评论数&nbsp;
                  <span :class="{hide:searchParams.commentNum==false}">↓</span>
                </a>
              </li>
            </ol>
          </section>
        </div>
        <div class="mt40">
          <!-- /无数据提示 开始-->
          <section class="no-data-wrap" v-if="data.total==0">
            <em class="icon30 no-data-ico">&nbsp;</em>
            <span class="c-666 fsize14 ml10 vam">没有相关数据，小编正在努力整理中...</span>
          </section>
          <!-- /无数据提示 结束-->
          <article  v-if="data.total>0" class="comm-course-list">
            <ul class="of" id="bna">
              <li v-for="item in data.courseCardVos" :key="item.courseId">
                <div class="cc-l-wrap">
                  <section class="course-img">
                    <img :src="item.courseCover" class="img-responsive" :alt="item.courseName">
                    <div class="cc-mask">
                      <a :href="'/course/'+item.courseId" title="开始学习" class="comm-btn c-btn-1">开始学习</a>
                    </div>
                  </section>
                  <h3 class="hLh30 txtOf mt10">
                    <a :href="'/course/'+item.courseId" :title="item.courseName" class="course-title fsize18 c-333">{{item.courseName}}</a>
                  </h3>
                  <section class="mt10 hLh20 of">
                    <span class="fl jgAttr c-ccc f-fA">
                      <i class="c-999 f-fA">{{ item.studentNum }}人学习</i>
                      |
                      <i class="c-999 f-fA">{{ item.commentNum }}条讨论</i>
                    </span>
                    <el-button type="text" class="button" style="padding-top:0px;float:right;font-size:15px;padding-right:20px" @click="savePeopleCourse(item.courseId)">选课</el-button>
                  </section>
                </div>
              </li>
              
            </ul>
            <div class="clear"></div>
          </article>
        </div>
        <!-- 公共分页 开始 -->
        <div>
      <div class="paging">
        <!-- undisable这个class是否存在，取决于数据属性hasPrevious -->
        <a
          :class="{undisable: !data.hasPrevious}"
          href="#"
          title="首页"
          @click.prevent="gotoPage(1)">首</a>
        <a
          :class="{undisable: !data.hasPrevious}"
          href="#"
          title="前一页"
          @click.prevent="gotoPage(data.current-1)">&lt;</a>
        <a
          v-for="page in data.pages"
          :key="page"
          :class="{current: data.current == page, undisable: data.current == page}"
          :title="'第'+page+'页'"
          href="#"
          @click.prevent="gotoPage(page)">{{ page }}</a>
        <a
          :class="{undisable: !data.hasNext}"
          href="#"
          title="后一页"
          @click.prevent="gotoPage(data.current+1)">&gt;</a>
        <a
          :class="{undisable: !data.hasNext}"
          href="#"
          title="末页"
          @click.prevent="gotoPage(data.pages)">末</a>
        <div class="clear"/>
      </div>
    </div>
      </section>
    </section>
    <!-- /课程列表 结束 -->
  </div>
</template>

<script>
import Category from '@/api/education/category'
import ES from '@/api/extension/elasticsearch'
import cookie from 'js-cookie'
import People from '@/api/education/people'

export default {
  data() {
    return {
      data: {},
      OneList:[],
      TwoList:[],
      oneIndex:-1,
      twoIndex:-1,
      searchParams: {
        keyword: null,
        categoryId : null,
        publish: false,
        studentNum: false,
        commentNum:false,
        current :1
      },
      page:1,
      peopleCourse: {
        peopelName: null,
        courseId: null,
      }
    }
  },
  created() {
    this.listAllParentCategory()
    this.searchCourseCardVo()
  },
  methods:{
    listAllParentCategory(){
      Category.listAllParentCategory()
        .then(res => {
          if(res.code === 20000){
            this.OneList = res.data.parentCategory
          }
        })
    },
    searchChildren(parentId,index){
      this.oneIndex = index
      this.twoIndex = -1
      this.searchParams.categoryId = null,
      Category.listChildrenCategoryByParentId(parentId)
        .then(res => {
          if(res.code === 20000){
            this.TwoList = res.data.childrenCategory
          }
        })
    },
    searchCourseCardVo(){
      ES.searchCourseCardVo(this.searchParams)
        .then(res => {
          if(res.code === 20000){
            this.data = res.data
          }
        })
    },
    gotoPage(current){
      this.searchParams.current=current
      this.searchCourseCardVo()
    },
    searchPublish(){
      this.searchParams.publish=!this.searchParams.publish
      this.searchCourseCardVo()
    },
    searchStudentNum(){
      this.searchParams.studentNum=!this.searchParams.studentNum
      this.searchCourseCardVo()
    },
    searchCommentNum(){
      this.searchParams.commentNum=!this.searchParams.commentNum
      this.searchCourseCardVo()
    },
    searchCategory(categoryId){
      this.searchParams.categoryId=categoryId
      this.searchCourseCardVo()
    },
    searchAll(){
      this.searchParams.categoryId=null
      this.searchCourseCardVo()
    },
    searchKeyword(){
      console.log(this.searchParams.keyword)
      this.searchCourseCardVo()
    },
    savePeopleCourse(courseId){
      var userStr = cookie.get('user')
      if(userStr){
        this.peopleCourse.peopleName = JSON.parse(userStr).username
      }else{
        window.location.href = "/login";
      }
      this.peopleCourse.courseId =courseId
      People.savePeopleCourse(this.peopleCourse)
      window.location.href = "/course";
    }
  }
};
</script>
<style scoped>
  .active {
    background: #bdbdbd;
  }
  .hide {
    display: none;
  }
  .show {
    display: block;
  }
</style>