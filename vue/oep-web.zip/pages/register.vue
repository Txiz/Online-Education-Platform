<template>
  <div class="main">
    <div class="title">
      <a href="/login">登录</a>
      <span>·</span>
      <a class="active" href="/register">注册</a>
    </div>
    <div class="sign-up-container">
      <el-form :model="params">

        <el-form-item class="input-prepend restyle " prop="peopleName">
          <div>
            <el-input type="text" placeholder="用户名" v-model="params.peopleName"/>
            <i class="iconfont icon-user"/>
          </div>
        </el-form-item>
        <el-form-item class="input-prepend restyle no-radius" prop="password">
          <div>
            <el-input type="password" placeholder="设置密码" v-model="params.password"/>
            <i class="iconfont icon-password"/>
          </div>
        </el-form-item>
        <el-form-item class="input-prepend" prop="nickName">
          <div>
            <el-input type="text" placeholder="用户昵称" v-model="params.nickName"/>
            <i class="iconfont icon-phone"/>
          </div>
        </el-form-item>
        <div class="btn">
          <input type="button" class="sign-up-button" value="注册" @click="submitRegister()">
        </div>
      </el-form>
    </div>
  </div>
</template>

<script>
import '~/assets/css/sign.css'
import '~/assets/css/iconfont.css'
import Index from '@/api/admin/index'

export default {
  layout: 'sign',
  data() {
    return {
      params: { //封装注册输入数据
        peopleName: '',
        nickName: '',
        password: ''
      },
    }
  },
  methods: {
     //注册提交的方法
     submitRegister() {
      Index.register(this.params)
        .then(res => {
          if(res.code === 20000){
            this.$router.replace('/login')
          }
        })
     },
  }
}
</script>
