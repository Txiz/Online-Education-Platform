<template>
  <div>
    <!-- 幻灯片 开始 -->
    <el-carousel height="500px" indicator-position='none'>
      <el-carousel-item v-for="item in bannerList" :key="item.bannerId">
        <el-image
          :src="item.bannerUrl">
        </el-image>
      </el-carousel-item>
    </el-carousel>
    <!-- 幻灯片 结束 -->
    <div id="aCoursesList">
      <div>
        <section class="container">
          <header class="comm-title">
            <h2 class="tac">
              <span class="c-333">最新课程</span>
            </h2>
          </header>
          <div>
            <article class="comm-course-list">
              <ul class="of" id="bna">
                <li v-for="course in courseCardVos" :key="course.courseId">
                  <div class="cc-l-wrap">
                    <section class="course-img">
                      <img
                        :src="course.courseCover"
                        class="img-responsive"
                        :alt="course.courseName"
                      >
                      <div class="cc-mask">
                        <a :href="'/course/'+course.courseId" :title="course.courseName" class="comm-btn c-btn-1">开始学习</a>
                      </div>
                    </section>
                    <h3 class="hLh30 txtOf mt10">
                      <a :href="'/course/'+course.courseId" :title="course.courseName" class="course-title fsize18 c-333">{{course.courseName}}</a>
                    </h3>
                    <section class="mt10 hLh20 of">
                      <span class="fl jgAttr c-ccc f-fA">
                        <i class="c-999 f-fA">{{course.studentNum}}人学习</i>
                        |
                        <i class="c-999 f-fA">{{course.commentNum}}评论</i>
                      </span>
                    </section>
                  </div>
                </li>
               
              </ul>
              <div class="clear"></div>
            </article>
            <section class="tac pt20">
              <a href="/course" title="全部课程" class="comm-btn c-btn-2">全部课程</a>
            </section>
          </div>
        </section>
      </div>
      <div>
        <section class="container">
          <header class="comm-title">
            <h2 class="tac">
              <span class="c-333">热门教师</span>
            </h2>
          </header>
          <div>
            <article class="i-teacher-list">
              <ul class="of">
                <li v-for="teacher in teacherList" :key="teacher.peopleId">
                  <section class="i-teach-wrap">
                    <div class="i-teach-pic">
                      <a :href="'/teacher/'+teacher.peopleId" :title="teacher.nickName">
                        <img :alt="teacher.nickName" :src="teacher.avatar">
                      </a>
                    </div>
                    <div class="mt10 hLh30 txtOf tac">
                      <a :href="'/teacher/'+teacher.peopleId" :title="teacher.nickName" class="fsize18 c-666">{{teacher.nickName}}</a>
                    </div>
                  </section>
                </li>
              </ul>
              <div class="clear"></div>
            </article>
            <section class="tac pt20">
              <a href="/teacher" title="全部讲师" class="comm-btn c-btn-2">全部讲师</a>
            </section>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>

<script>
import Banner from '@/api/extension/banner'
import People from '@/api/education/people'
import ES from '@/api/extension/elasticsearch'

export default {
  data () {
    return {
      bannerList: [],
      courseCardVos: [],
      teacherList: [],
    }
  },
  created() {
    this.listBanner()
    this.getNewCourseCardVo()
    this.listHotTeacher()
  },
  methods:{
    listBanner(){
      Banner.listBanner()
        .then(res => {
          if(res.code === 20000){
            this.bannerList = res.data.bannerList
          }
      })
    },
    getNewCourseCardVo(){
      ES.getNewCourseCardVo()
        .then(res => {
          if(res.code === 20000){
            this.courseCardVos = res.data.courseCardVos
          }
        })
    },
    listHotTeacher(){
      People.listHotTeacher()
        .then(res => {
          if(res.code === 20000){
            this.teacherList = res.data.teacherList
          }
        })
    }
  }
}
</script>

<style scoped>

</style>