<template>
  <div id="aCoursesList" class="bg-fa of">
    <!-- /课程列表 开始 -->
    <section class="container">
      <header class="comm-title">
        <h2 class="fl tac">
          <span class="c-333">我的课程</span>
        </h2>
      </header>
      <section class="c-sort-box">
        <section class="c-s-dl">
        <div class="mt40">
          <!-- /无数据提示 结束-->
          <article class="comm-course-list">
            <ul class="of" id="bna">
              <li v-for="item in data.courseCardVos" :key="item.courseId">
                <div class="cc-l-wrap">
                  <section class="course-img">
                    <img :src="item.courseCover" class="img-responsive" :alt="item.courseName">
                    <div class="cc-mask">
                      <a :href="'/course/'+item.courseId" title="开始学习" class="comm-btn c-btn-1">开始学习</a>
                    </div>
                  </section>
                  <h3 class="hLh30 txtOf mt10">
                    <a :href="'/course/'+item.courseId" :title="item.courseName" class="course-title fsize18 c-333">{{item.courseName}}</a>
                  </h3>
                  <section class="mt10 hLh20 of">
                    <span class="fl jgAttr c-ccc f-fA">
                      <i class="c-999 f-fA">{{ item.studentNum }}人学习</i>
                      |
                      <i class="c-999 f-fA">{{ item.commentNum }}条讨论</i>
                    </span>
                    <el-button type="text" class="button" style="padding-top:0px;float:right;font-size:15px;padding-right:20px" @click="deletePeopleCourse(item.courseId)">退课</el-button>
                  </section>
                </div>
              </li>
              
            </ul>
            <div class="clear"></div>
          </article>
        </div>
        </section>
      </section>
    <!-- /课程列表 结束 -->
    </section>
  </div>
</template>

<script>
import People from '@/api/education/people'
import cookie from 'js-cookie'
export default {
  data() {
    return {
      data: {},
      peopleCourse: {
        peopelName: null,
        courseId: null,
      }
    }
  },
  created() {
    this.getCourse()
  },
  methods:{
    getCourse(){
      var userStr = cookie.get('user')
      if(userStr){
        People.getByPeopleName(JSON.parse(userStr).username)
        .then(res => {
          if(res.code === 20000){
            this.data = res.data

          }
        })
      }
    },
    deletePeopleCourse(courseId){
      var userStr = cookie.get('user')
      if(userStr){
        this.peopleCourse.peopleName = JSON.parse(userStr).username
      }else{
        window.location.href = "/login";
      }
      this.peopleCourse.courseId =courseId
      People.deletePeopleCourse(this.peopleCourse)
      window.location.href = "/home";
    }
  }
};
</script>
<style scoped>
  .active {
    background: #bdbdbd;
  }
  .hide {
    display: none;
  }
  .show {
    display: block;
  }
</style>