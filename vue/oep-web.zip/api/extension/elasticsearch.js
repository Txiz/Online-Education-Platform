import request from '@/utils/request' 

export default {
  getNewCourseCardVo(){
    return request({
      url: `/extension/elasticsearch/getNewCourseCardVo`,
      method: 'get',
    })
  },
  searchCourseCardVo(searchParam){
    return request({
      url: `/extension/elasticsearch/searchCourseCardVo`,
      method: 'post',
      data: searchParam
    })
  }
}