import request from '@/utils/request' 

export default {
  listBanner(){
    return request({
      url: `/extension/banner/listBanner`,
      method: 'get',
    })
  }
}