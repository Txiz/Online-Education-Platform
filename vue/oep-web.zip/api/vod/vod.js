import request from '@/utils/request' 

export default {
    // 根据视频url获取视频播放凭证
    getPlayAuth(videoUrl){
      return request({
        url: `/vod/getPlayAuth/${videoUrl}`,
        method: 'get'
      })
    },
}