import request from '@/utils/request' 

export default {
  listAllParentCategory(){
    return request({
      url: `/education/category/listAllParentCategory`,
      method: 'get',
    })
  },
  listChildrenCategoryByParentId(parentId){
    return request({
      url: `/education/category//listChildrenCategoryByParentId/${parentId}`,
      method: 'get',
    })
  },
}