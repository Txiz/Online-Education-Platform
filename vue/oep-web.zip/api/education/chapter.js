import request from '@/utils/request' 

export default {
  listAllChapter(courseId){
    return request({
      url: `/education/chapter/listAllChapter/${courseId}`,
      method: 'get',
    })
  },
}