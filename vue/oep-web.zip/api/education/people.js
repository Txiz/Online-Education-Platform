import request from '@/utils/request' 

export default {
  listHotTeacher(){
    return request({
      url: `/education/people/listHotTeacher`,
      method: 'get',
    })
  },
  listAllTeacher(current){
    return request({
      url: `/education/people/listAllTeacher/${current}`,
      method: 'get',
    })
  },
  getByPeopleId(peopleId){
    return request({
      url: `/education/people/getByPeopleId/${peopleId}`,
      method: 'get',
    })
  },
  savePeopleCourse(peopleCourse){
    return request({
      url: `/education/people/savePeopleCourse`,
      method: 'post',
      data: peopleCourse
    })
  },
  getByPeopleName(peopleName){
    return request({
      url: `/education/people/getByPeopleName/${peopleName}`,
      method: 'get',
    })
  },
  deletePeopleCourse(peopleCourse){
    return request({
      url: `/education/people/deletePeopleCourse`,
      method: 'delete',
      data: peopleCourse
    })
  },
}