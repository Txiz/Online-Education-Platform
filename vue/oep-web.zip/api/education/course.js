import request from '@/utils/request' 

export default {
  getByCourseId(courseId){
    return request({
      url: `/education/course/getByCourseId/${courseId}`,
      method: 'get',
    })
  },
}